export interface Subject {
  id: string;
  name: string;
  color: string;
  createdAt: string;
}

export interface Task {
  id: string;
  title: string;
  subjectId: string;
  date: string; // YYYY-MM-DD
  targetPomodoros: number;
  completedPomodoros: number;
  completed: boolean;
  completedAt?: string;
  createdAt: string;
  notes?: string;
  actualMinutes?: number; // Real minutes spent on this task
  actualSeconds?: number; // Precise seconds spent on this task
}

export interface PomodoroSession {
  id: string;
  taskId?: string;
  subjectId: string;
  topicName: string;
  durationMinutes: number; // Real minutes spent (compatibility)
  durationSeconds?: number; // Precise seconds spent
  isFull?: boolean; // True only if completed the full focus duration
  completedAt: string; // ISO string
  date: string; // YYYY-MM-DD
  type: 'focus' | 'short_break' | 'long_break';
}

export interface AppSettings {
  focusMinutes: number;
  shortBreakMinutes: number;
  longBreakMinutes: number;
  soundAlert: boolean;
  darkMode: boolean;
  streakDays: number;
}

export type TabType = 'today' | 'subjects' | 'settings';
