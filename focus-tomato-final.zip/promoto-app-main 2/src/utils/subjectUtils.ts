import { Subject } from '../types';

export const UNCATEGORIZED_SUBJECT_ID = 'uncategorized';
export const UNCATEGORIZED_SUBJECT_NAME = '未分類';
export const UNCATEGORIZED_COLOR = '#78716C'; // Warm stone neutral

export const createUncategorizedSubject = (): Subject => ({
  id: UNCATEGORIZED_SUBJECT_ID,
  name: UNCATEGORIZED_SUBJECT_NAME,
  color: UNCATEGORIZED_COLOR,
  createdAt: new Date().toISOString(),
});

export const ensureUncategorizedSubject = (
  subjects: Subject[]
): { subjects: Subject[]; uncategorizedId: string } => {
  const existing = subjects.find(
    (s) => s.id === UNCATEGORIZED_SUBJECT_ID || s.name === UNCATEGORIZED_SUBJECT_NAME
  );

  if (existing) {
    return { subjects, uncategorizedId: existing.id };
  }

  const newSub = createUncategorizedSubject();
  return {
    subjects: [...subjects, newSub],
    uncategorizedId: newSub.id,
  };
};
