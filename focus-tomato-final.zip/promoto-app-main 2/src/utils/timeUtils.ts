/**
 * Utility functions for precise time formatting down to minutes and seconds
 */

export const formatDurationZh = (totalSeconds: number): string => {
  const s = Math.max(0, Math.round(totalSeconds));
  if (s === 0) return '0 秒';

  const hours = Math.floor(s / 3600);
  const minutes = Math.floor((s % 3600) / 60);
  const seconds = s % 60;

  if (hours > 0) {
    if (minutes === 0 && seconds === 0) return `${hours} 小時`;
    if (seconds === 0) return `${hours} 小時 ${minutes} 分鐘`;
    if (minutes === 0) return `${hours} 小時 ${seconds} 秒`;
    return `${hours} 小時 ${minutes} 分鐘 ${seconds} 秒`;
  }

  if (minutes > 0) {
    if (seconds === 0) return `${minutes} 分鐘`;
    return `${minutes} 分鐘 ${seconds} 秒`;
  }

  return `${seconds} 秒`;
};

export const formatDurationShort = (totalSeconds: number): string => {
  const s = Math.max(0, Math.round(totalSeconds));
  if (s < 60) return `${s}s`;
  const m = Math.floor(s / 60);
  const remS = s % 60;
  if (remS === 0) return `${m}m`;
  return `${m}m ${remS}s`;
};

export const getSessionSeconds = (session: { durationSeconds?: number; durationMinutes: number }): number => {
  if (session.durationSeconds !== undefined && session.durationSeconds > 0) {
    return session.durationSeconds;
  }
  return (session.durationMinutes || 0) * 60;
};

export const getTaskSeconds = (task: { actualSeconds?: number; actualMinutes?: number }): number => {
  if (task.actualSeconds !== undefined && task.actualSeconds > 0) {
    return task.actualSeconds;
  }
  return (task.actualMinutes || 0) * 60;
};
