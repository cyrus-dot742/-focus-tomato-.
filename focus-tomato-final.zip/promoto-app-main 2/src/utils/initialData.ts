import { Subject, Task, PomodoroSession, AppSettings } from '../types';

export const INITIAL_SUBJECTS: Subject[] = [];

export const INITIAL_TASKS: Task[] = [];

export const INITIAL_SESSIONS: PomodoroSession[] = [];

export const INITIAL_SETTINGS: AppSettings = {
  focusMinutes: 25,
  shortBreakMinutes: 5,
  longBreakMinutes: 15,
  soundAlert: true,
  darkMode: false,
  streakDays: 0,
};
