import React from 'react';
import { Calendar, BookOpen, Settings } from 'lucide-react';
import { TabType } from '../types';

interface BottomNavBarProps {
  activeTab: TabType;
  onTabChange: (tab: TabType) => void;
}

export const BottomNavBar: React.FC<BottomNavBarProps> = ({
  activeTab,
  onTabChange,
}) => {
  const tabs: Array<{ id: TabType; label: string; icon: React.ReactNode }> = [
    {
      id: 'today',
      label: '今日',
      icon: <Calendar size={22} strokeWidth={activeTab === 'today' ? 2.3 : 1.8} />,
    },
    {
      id: 'subjects',
      label: '科目',
      icon: <BookOpen size={22} strokeWidth={activeTab === 'subjects' ? 2.3 : 1.8} />,
    },
    {
      id: 'settings',
      label: '設定',
      icon: <Settings size={22} strokeWidth={activeTab === 'settings' ? 2.3 : 1.8} />,
    },
  ];

  return (
    <nav
      className="sticky bottom-0 left-0 right-0 z-30 bg-white/95 dark:bg-stone-900/95 backdrop-blur-md border-t border-stone-200/80 dark:border-stone-800 transition-colors"
      aria-label="主要導航"
    >
      <div className="grid grid-cols-3 max-w-md mx-auto">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`flex flex-col items-center justify-center min-h-[58px] py-1.5 transition-all select-none active:scale-95 ${
                isActive
                  ? 'text-[#E2583E] dark:text-[#F87171] font-semibold'
                  : 'text-stone-400 dark:text-stone-500 hover:text-stone-600 dark:hover:text-stone-300'
              }`}
            >
              <div className="relative">
                {tab.icon}
                {isActive && (
                  <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-[#E2583E] dark:bg-[#F87171]" />
                )}
              </div>
              <span className="text-[11px] tracking-tight mt-1">
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
      {/* iOS Home Indicator Pill */}
      <div className="w-full flex justify-center pb-2 pt-0.5">
        <div className="w-32 h-1 bg-stone-300 dark:bg-stone-700 rounded-full" />
      </div>
    </nav>
  );
};
