import React, { useId } from 'react';

interface TomatoIconProps {
  size?: number;
  filled?: boolean;
  partial?: boolean;
  className?: string;
}

export const TomatoIcon: React.FC<TomatoIconProps> = ({
  size = 18,
  filled = true,
  partial = false,
  className = '',
}) => {
  const uniqueId = useId().replace(/:/g, '');
  const gradId = `tomato-gradient-${uniqueId}`;
  const clipId = `tomato-half-clip-${uniqueId}`;

  // 1. Incomplete / unstarted: empty outline tomato
  if (!filled && !partial) {
    return (
      <svg
        width={size}
        height={size}
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
        className={`inline-block text-stone-300 transition-colors ${className}`}
      >
        {/* Calyx / Leaves */}
        <path d="M12 4.5V2" stroke="#15803D" strokeWidth="2" />
        <path d="M12 4.5C10.5 3.5 8 4 7 5C8.5 5.5 10 5.5 12 4.5Z" fill="#16A34A" stroke="#16A34A" strokeWidth="0.5" />
        <path d="M12 4.5C13.5 3.5 16 4 17 5C15.5 5.5 14 5.5 12 4.5Z" fill="#16A34A" stroke="#16A34A" strokeWidth="0.5" />
        {/* Empty Tomato Outline */}
        <circle cx="12" cy="13.5" r="7.5" stroke="#D1D5DB" strokeWidth="1.8" strokeDasharray="1.5 0" />
      </svg>
    );
  }

  // 2. Partial tomato: ended early by clicking ✓, not a full tomato
  if (partial && !filled) {
    return (
      <svg
        width={size}
        height={size}
        viewBox="0 0 24 24"
        fill="none"
        className={`inline-block shrink-0 ${className}`}
      >
        <defs>
          <radialGradient
            id={gradId}
            cx="35%"
            cy="35%"
            r="65%"
            fx="30%"
            fy="30%"
          >
            <stop offset="0%" stopColor="#FF6B55" />
            <stop offset="60%" stopColor="#E2583E" />
            <stop offset="100%" stopColor="#C43820" />
          </radialGradient>
          <clipPath id={clipId}>
            <rect x="0" y="0" width="12" height="24" />
          </clipPath>
        </defs>

        {/* Stem */}
        <path
          d="M12 5V2.2C12 2.2 12.8 1.8 13.5 2.5"
          stroke="#15803D"
          strokeWidth="1.8"
          strokeLinecap="round"
        />
        {/* Leaves */}
        <path
          d="M12 5C10.2 3.8 7.5 4.5 6.5 5.5C8.2 6.1 10.2 5.9 12 5Z"
          fill="#22C55E"
        />
        <path
          d="M12 5C13.8 3.8 16.5 4.5 17.5 5.5C15.8 6.1 13.8 5.9 12 5Z"
          fill="#16A34A"
          stroke="#16A34A"
          strokeWidth="0.5"
          strokeDasharray="1.5 1"
          opacity="0.8"
        />
        <path
          d="M11 5C11.5 3.5 12.5 3.5 13 5C12.3 5.3 11.7 5.3 11 5Z"
          fill="#15803D"
        />

        {/* Empty right half outline (dashed) */}
        <path
          d="M 12 6 A 8 7.5 0 0 1 12 21"
          stroke="#CBD5E1"
          strokeWidth="1.6"
          strokeDasharray="2.5 2"
          fill="none"
        />

        {/* Left half filled with tomato gradient */}
        <g clipPath={`url(#${clipId})`}>
          <ellipse
            cx="12"
            cy="13.5"
            rx="8"
            ry="7.5"
            fill={`url(#${gradId})`}
          />
          {/* Gloss Highlight on left */}
          <path
            d="M8.5 9.5C6.8 11.2 6.5 13.5 6.8 14.5C6.4 13.8 6.5 11.8 8 10C9.2 8.5 11 8.2 12 8.2C10.5 8.3 9.3 8.7 8.5 9.5Z"
            fill="white"
            opacity="0.45"
          />
        </g>

        {/* Vertical subtle center line indicating half */}
        <line
          x1="12"
          y1="6"
          x2="12"
          y2="21"
          stroke="#E2583E"
          strokeWidth="1.2"
          strokeDasharray="2 1.5"
          opacity="0.8"
        />
      </svg>
    );
  }

  // 3. Full tomato: awarded ONLY when the full time has passed
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      className={`inline-block shrink-0 ${className}`}
    >
      <defs>
        <radialGradient
          id={gradId}
          cx="35%"
          cy="35%"
          r="65%"
          fx="30%"
          fy="30%"
        >
          <stop offset="0%" stopColor="#FF6B55" />
          <stop offset="60%" stopColor="#E2583E" />
          <stop offset="100%" stopColor="#C43820" />
        </radialGradient>
      </defs>

      {/* Stem */}
      <path
        d="M12 5V2.2C12 2.2 12.8 1.8 13.5 2.5"
        stroke="#15803D"
        strokeWidth="1.8"
        strokeLinecap="round"
      />
      {/* Leaves */}
      <path
        d="M12 5C10.2 3.8 7.5 4.5 6.5 5.5C8.2 6.1 10.2 5.9 12 5Z"
        fill="#22C55E"
      />
      <path
        d="M12 5C13.8 3.8 16.5 4.5 17.5 5.5C15.8 6.1 13.8 5.9 12 5Z"
        fill="#16A34A"
      />
      <path
        d="M11 5C11.5 3.5 12.5 3.5 13 5C12.3 5.3 11.7 5.3 11 5Z"
        fill="#15803D"
      />
      {/* Tomato Body */}
      <ellipse
        cx="12"
        cy="13.5"
        rx="8"
        ry="7.5"
        fill={`url(#${gradId})`}
      />
      {/* Gloss Highlight */}
      <path
        d="M8.5 9.5C6.8 11.2 6.5 13.5 6.8 14.5C6.4 13.8 6.5 11.8 8 10C9.2 8.5 11 8.2 12 8.2C10.5 8.3 9.3 8.7 8.5 9.5Z"
        fill="white"
        opacity="0.45"
      />
    </svg>
  );
};

export default TomatoIcon;
