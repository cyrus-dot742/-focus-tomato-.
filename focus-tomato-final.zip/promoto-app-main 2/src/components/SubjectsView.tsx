import React, { useState } from 'react';
import { Pencil, Plus, X, Trash2, ChevronRight, AlertTriangle, FolderOpen } from 'lucide-react';
import { Subject, Task, PomodoroSession } from '../types';
import { UNCATEGORIZED_SUBJECT_ID, UNCATEGORIZED_SUBJECT_NAME } from '../utils/subjectUtils';
import { formatDurationZh, getSessionSeconds } from '../utils/timeUtils';
import { TomatoIcon } from './TomatoIcon';

interface SubjectsViewProps {
  subjects: Subject[];
  tasks: Task[];
  sessions: PomodoroSession[];
  onSelectSubject: (subject: Subject) => void;
  onAddSubject: (name: string, color: string) => void;
  onUpdateSubject: (id: string, name: string, color: string) => void;
  onDeleteSubject: (id: string) => void;
}

const PRESET_COLORS = [
  '#F97316', // Orange (Math)
  '#3B82F6', // Blue (English)
  '#8B5CF6', // Purple (Physics)
  '#10B981', // Emerald (Chemistry)
  '#E11D48', // Crimson/Rose (Chinese)
  '#64748B', // Slate (Liberal Studies)
  '#F59E0B', // Amber
  '#06B6D4', // Cyan
  '#EC4899', // Pink
  '#84CC16', // Lime
  '#78716C', // Warm Stone (Uncategorized default)
];

export const SubjectsView: React.FC<SubjectsViewProps> = ({
  subjects,
  tasks,
  sessions,
  onSelectSubject,
  onAddSubject,
  onUpdateSubject,
  onDeleteSubject,
}) => {
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingSubject, setEditingSubject] = useState<Subject | null>(null);
  const [subjectToDelete, setSubjectToDelete] = useState<Subject | null>(null);

  const [nameInput, setNameInput] = useState('');
  const [colorInput, setColorInput] = useState(PRESET_COLORS[0]);

  const openAddModal = () => {
    setNameInput('');
    setColorInput(PRESET_COLORS[subjects.length % PRESET_COLORS.length]);
    setIsAddModalOpen(true);
  };

  const openEditModal = (subject: Subject, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingSubject(subject);
    setNameInput(subject.name);
    setColorInput(subject.color);
  };

  const openDeleteModal = (subject: Subject, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setSubjectToDelete(subject);
  };

  const handleConfirmDelete = () => {
    if (!subjectToDelete) return;
    onDeleteSubject(subjectToDelete.id);
    if (editingSubject?.id === subjectToDelete.id) {
      setEditingSubject(null);
    }
    setSubjectToDelete(null);
  };

  const handleSaveAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nameInput.trim()) return;
    onAddSubject(nameInput.trim(), colorInput);
    setIsAddModalOpen(false);
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingSubject || !nameInput.trim()) return;
    onUpdateSubject(editingSubject.id, nameInput.trim(), colorInput);
    setEditingSubject(null);
  };

  return (
    <div className="pb-28 px-4 pt-1 max-w-md mx-auto">
      {/* Delete Subject Confirmation Modal (Custom in-app UI, zero window.confirm) */}
      {subjectToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/70 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-white dark:bg-stone-800 rounded-3xl p-6 max-w-xs w-full text-center shadow-2xl border border-stone-200 dark:border-stone-700 animate-in zoom-in-95 duration-150">
            <div className="w-12 h-12 rounded-full bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 mx-auto flex items-center justify-center mb-3">
              <AlertTriangle size={24} />
            </div>
            <h3 className="text-base font-bold text-stone-900 dark:text-white">
              確定要刪除科目「{subjectToDelete.name}」？
            </h3>
            <p className="text-xs text-stone-500 dark:text-stone-400 mt-2 leading-relaxed text-left bg-stone-50 dark:bg-stone-900/60 p-3 rounded-xl border border-stone-200/60 dark:border-stone-700/60">
              📌 <strong>數據保護</strong>：刪除後，該科目下的所有主題、任務與溫習紀錄將會<strong>自動移至「未分類」科目</strong>中，溫習歷程與時間紀錄不會丟失！
            </p>
            <div className="flex gap-2.5 mt-5">
              <button
                type="button"
                onClick={() => setSubjectToDelete(null)}
                className="flex-1 py-2.5 text-xs font-semibold bg-stone-100 dark:bg-stone-700 text-stone-700 dark:text-stone-200 rounded-xl hover:bg-stone-200 dark:hover:bg-stone-600 transition-colors cursor-pointer"
              >
                取消
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                className="flex-1 py-2.5 text-xs font-bold bg-rose-600 hover:bg-rose-700 text-white rounded-xl shadow-xs transition-colors cursor-pointer"
              >
                確認刪除
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <header className="py-3">
        <h1 className="text-xl font-bold tracking-tight text-stone-900 dark:text-stone-100">
          科目設定
        </h1>
        <p className="text-xs text-stone-500 dark:text-stone-400 mt-1">
          管理你的溫習科目，分配專屬標籤顏色與歷程
        </p>
      </header>

      {/* Subject List */}
      <div className="mt-3 space-y-3">
        {subjects.length === 0 ? (
          <div className="text-center py-12 px-4 bg-white dark:bg-stone-800 rounded-2xl border border-dashed border-stone-200 dark:border-stone-700">
            <div className="w-12 h-12 mx-auto rounded-full bg-orange-50 dark:bg-stone-700 flex items-center justify-center text-orange-500 mb-2">
              <Plus size={24} />
            </div>
            <p className="text-sm font-semibold text-stone-700 dark:text-stone-300">
              目前尚未建立任何溫習科目
            </p>
            <p className="text-xs text-stone-400 mt-1 mb-4">
              點擊下方按鈕新增科目，為你的學習安排專屬科目與顏色
            </p>
            <button
              onClick={openAddModal}
              className="px-4 py-2 text-xs font-bold text-white bg-[#E2583E] rounded-xl hover:bg-[#D1492F] shadow-xs transition-colors cursor-pointer"
            >
              + 新增第一個科目
            </button>
          </div>
        ) : (
          subjects.map((sub) => {
            // Calculate quick stats from sessions & tasks (precise to the second)
            const subSessions = sessions.filter((s) => s.subjectId === sub.id);
            const focusSessions = subSessions.filter((s) => s.type === 'focus');
            const totalDurationSeconds = subSessions.reduce((acc, s) => acc + getSessionSeconds(s), 0);
            const fullPomodoros = focusSessions.filter((s) => s.isFull).length;
            const partialPomodoros = Math.max(0, focusSessions.length - fullPomodoros);
            const isUncategorized = sub.id === UNCATEGORIZED_SUBJECT_ID || sub.name === UNCATEGORIZED_SUBJECT_NAME;

            return (
              <div
                key={sub.id}
                onClick={() => onSelectSubject(sub)}
                className="group bg-white dark:bg-stone-800 rounded-2xl p-4 shadow-xs border border-stone-200/70 dark:border-stone-700/60 hover:border-orange-300 dark:hover:border-stone-600 transition-all flex items-center justify-between cursor-pointer active:scale-99"
              >
                <div className="flex items-center gap-3 flex-1 min-w-0">
                  {/* Dot with Color */}
                  <span
                    className="w-3.5 h-3.5 rounded-full shrink-0 shadow-xs"
                    style={{ backgroundColor: sub.color }}
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-base font-semibold text-stone-900 dark:text-stone-100 group-hover:text-[#E2583E] transition-colors truncate">
                        {sub.name}
                      </span>
                      {isUncategorized && (
                        <span className="text-[10px] px-2 py-0.5 rounded-md bg-stone-100 dark:bg-stone-700 text-stone-500 dark:text-stone-400 font-medium shrink-0">
                          未分類
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-2 text-[11px] text-stone-500 dark:text-stone-400 mt-1">
                      {focusSessions.length > 0 ? (
                        <div className="flex items-center gap-2 font-medium">
                          <div className="flex items-center gap-0.5">
                            {focusSessions.map((s, idx) => (
                              <TomatoIcon
                                key={s.id || idx}
                                size={13}
                                filled={s.isFull}
                                partial={!s.isFull}
                              />
                            ))}
                          </div>
                          <span className="text-stone-300 dark:text-stone-600">•</span>
                          <span className="font-semibold text-stone-700 dark:text-stone-300">{formatDurationZh(totalDurationSeconds)}</span>
                        </div>
                      ) : (
                        <span>尚無溫習紀錄 · 點擊查看歷程</span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Right Actions: Delete + Edit + Chevron */}
                <div className="flex items-center gap-1 shrink-0 ml-2">
                  {/* Delete Subject Button */}
                  <button
                    onClick={(e) => openDeleteModal(sub, e)}
                    className="w-8 h-8 rounded-full flex items-center justify-center text-stone-300 hover:text-rose-500 dark:hover:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors cursor-pointer"
                    title={`刪除科目「${sub.name}」`}
                    aria-label={`刪除科目 ${sub.name}`}
                    type="button"
                  >
                    <Trash2 size={15} />
                  </button>

                  {/* Edit Subject Button */}
                  <button
                    onClick={(e) => openEditModal(sub, e)}
                    className="w-8 h-8 rounded-full flex items-center justify-center text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-700 transition-colors cursor-pointer"
                    title={`編輯科目「${sub.name}」`}
                    aria-label={`編輯 ${sub.name}`}
                    type="button"
                  >
                    <Pencil size={15} />
                  </button>
                  <ChevronRight size={18} className="text-stone-300 dark:text-stone-600 group-hover:translate-x-0.5 transition-transform" />
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Bottom Sticky Action Button: + 新增科目 */}
      <div className="mt-8">
        <button
          onClick={openAddModal}
          type="button"
          className="w-full py-3.5 px-4 bg-[#E2583E] hover:bg-[#D1492F] active:scale-98 text-white font-bold rounded-2xl shadow-lg shadow-orange-500/25 flex items-center justify-center gap-2 transition-all text-sm cursor-pointer"
        >
          <Plus size={18} strokeWidth={2.5} />
          <span>+ 新增科目</span>
        </button>
      </div>

      {/* Add Subject Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white dark:bg-stone-800 rounded-3xl w-full max-w-sm p-5 shadow-2xl border border-stone-200 dark:border-stone-700">
            <div className="flex items-center justify-between pb-3 border-b border-stone-100 dark:border-stone-700">
              <h3 className="text-base font-bold text-stone-900 dark:text-stone-100">
                新增科目
              </h3>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="w-8 h-8 flex items-center justify-center rounded-full text-stone-400 hover:text-stone-600 cursor-pointer"
                type="button"
              >
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleSaveAdd} className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-stone-600 dark:text-stone-300 mb-1.5">
                  科目名稱
                </label>
                <input
                  type="text"
                  required
                  placeholder="例：經濟、生物、地理"
                  value={nameInput}
                  onChange={(e) => setNameInput(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-stone-50 dark:bg-stone-900 border border-stone-200 dark:border-stone-700 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#E2583E] dark:text-white"
                  autoFocus
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-600 dark:text-stone-300 mb-1.5">
                  標籤顏色
                </label>
                <div className="grid grid-cols-5 gap-2.5">
                  {PRESET_COLORS.map((c) => (
                    <button
                      type="button"
                      key={c}
                      onClick={() => setColorInput(c)}
                      className={`h-9 rounded-xl flex items-center justify-center transition-all cursor-pointer ${
                        colorInput === c
                          ? 'ring-2 ring-offset-2 ring-stone-900 dark:ring-white scale-105'
                          : 'hover:scale-105'
                      }`}
                      style={{ backgroundColor: c }}
                    />
                  ))}
                </div>
              </div>

              <div className="pt-2 flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="flex-1 py-2.5 text-xs font-semibold text-stone-600 dark:text-stone-300 bg-stone-100 dark:bg-stone-700 rounded-xl cursor-pointer"
                >
                  取消
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 text-xs font-bold text-white bg-[#E2583E] hover:bg-[#D1492F] rounded-xl shadow-md shadow-orange-500/25 cursor-pointer"
                >
                  儲存
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Subject Modal */}
      {editingSubject && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white dark:bg-stone-800 rounded-3xl w-full max-w-sm p-5 shadow-2xl border border-stone-200 dark:border-stone-700">
            <div className="flex items-center justify-between pb-3 border-b border-stone-100 dark:border-stone-700">
              <h3 className="text-base font-bold text-stone-900 dark:text-stone-100">
                編輯科目「{editingSubject.name}」
              </h3>
              <button
                onClick={() => setEditingSubject(null)}
                className="w-8 h-8 flex items-center justify-center rounded-full text-stone-400 hover:text-stone-600 cursor-pointer"
                type="button"
              >
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-stone-600 dark:text-stone-300 mb-1.5">
                  科目名稱
                </label>
                <input
                  type="text"
                  required
                  value={nameInput}
                  onChange={(e) => setNameInput(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-stone-50 dark:bg-stone-900 border border-stone-200 dark:border-stone-700 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#E2583E] dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-600 dark:text-stone-300 mb-1.5">
                  標籤顏色
                </label>
                <div className="grid grid-cols-5 gap-2.5">
                  {PRESET_COLORS.map((c) => (
                    <button
                      type="button"
                      key={c}
                      onClick={() => setColorInput(c)}
                      className={`h-9 rounded-xl flex items-center justify-center transition-all cursor-pointer ${
                        colorInput === c
                          ? 'ring-2 ring-offset-2 ring-stone-900 dark:ring-white scale-105'
                          : 'hover:scale-105'
                      }`}
                      style={{ backgroundColor: c }}
                    />
                  ))}
                </div>
              </div>

              <div className="pt-2 flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={() => openDeleteModal(editingSubject)}
                  className="p-2.5 text-xs font-semibold text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-xl flex items-center gap-1 transition-colors cursor-pointer"
                >
                  <Trash2 size={16} />
                  <span>刪除此科目</span>
                </button>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setEditingSubject(null)}
                    className="py-2.5 px-4 text-xs font-semibold text-stone-600 dark:text-stone-300 bg-stone-100 dark:bg-stone-700 rounded-xl cursor-pointer"
                  >
                    取消
                  </button>
                  <button
                    type="submit"
                    className="py-2.5 px-5 text-xs font-bold text-white bg-[#E2583E] hover:bg-[#D1492F] rounded-xl shadow-md shadow-orange-500/25 cursor-pointer"
                  >
                    儲存修改
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
