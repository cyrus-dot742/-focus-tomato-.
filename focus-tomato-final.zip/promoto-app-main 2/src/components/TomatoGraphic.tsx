import React from 'react';

interface TomatoGraphicProps {
  timeDisplay: string; // e.g. "24:59"
  isRunning?: boolean;
  progressPercent?: number; // 0 to 100
  sessionType?: 'focus' | 'short_break' | 'long_break';
  size?: 'sm' | 'md' | 'lg';
  onClick?: () => void;
  className?: string;
}

export const TomatoGraphic: React.FC<TomatoGraphicProps> = ({
  timeDisplay,
  isRunning = false,
  progressPercent = 100,
  sessionType = 'focus',
  size = 'lg',
  onClick,
  className = '',
}) => {
  const isBreak = sessionType !== 'focus';

  // Size dimensions
  const dims = {
    sm: { width: 140, height: 140, fontSize: 'text-lg font-bold', subSize: 'text-[10px]' },
    md: { width: 220, height: 220, fontSize: 'text-3xl font-extrabold', subSize: 'text-xs' },
    lg: { width: 290, height: 290, fontSize: 'text-4xl font-extrabold', subSize: 'text-sm' },
  }[size];

  // Circle progress calculation (around the tomato)
  const radius = 126;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (progressPercent / 100) * circumference;

  return (
    <div
      onClick={onClick}
      className={`relative inline-flex flex-col items-center justify-center select-none ${
        onClick ? 'cursor-pointer' : ''
      } ${className}`}
      style={{ width: dims.width, height: dims.height }}
    >
      <svg
        viewBox="0 0 300 300"
        className={`w-full h-full drop-shadow-xl transition-transform duration-300 ${
          isRunning ? 'scale-105' : 'scale-100'
        }`}
      >
        <defs>
          {/* Main tomato 3D gradient */}
          <radialGradient id="tomato-body-grad" cx="35%" cy="30%" r="70%">
            <stop offset="0%" stopColor={isBreak ? '#34D399' : '#FF7865'} />
            <stop offset="50%" stopColor={isBreak ? '#10B981' : '#E2583E'} />
            <stop offset="90%" stopColor={isBreak ? '#059669' : '#C13922'} />
            <stop offset="100%" stopColor={isBreak ? '#047857' : '#9E2814'} />
          </radialGradient>

          {/* Stem & Leaves gradient */}
          <linearGradient id="leaf-grad-1" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#4ADE80" />
            <stop offset="100%" stopColor="#15803D" />
          </linearGradient>
          <linearGradient id="leaf-grad-2" x1="100%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#86EFAC" />
            <stop offset="100%" stopColor="#16A34A" />
          </linearGradient>

          {/* Clock glass badge gradient inside the tomato */}
          <linearGradient id="clock-glass" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="white" stopOpacity="0.3" />
            <stop offset="100%" stopColor="white" stopOpacity="0.08" />
          </linearGradient>

          {/* Soft ambient shadow filter */}
          <filter id="tomato-shadow" x="-10%" y="-10%" width="130%" height="130%">
            <feDropShadow dx="0" dy="12" stdDeviation="10" floodColor={isBreak ? '#065F46' : '#991B1B'} floodOpacity="0.25" />
          </filter>
        </defs>

        {/* Circular Progress Ring Background */}
        <circle
          cx="150"
          cy="155"
          r={radius}
          fill="none"
          stroke={isBreak ? '#A7F3D0' : '#FED7AA'}
          strokeWidth="6"
          strokeOpacity="0.4"
          strokeDasharray="4 4"
        />

        {/* Dynamic Circular Progress Indicator */}
        <circle
          cx="150"
          cy="155"
          r={radius}
          fill="none"
          stroke={isBreak ? '#10B981' : '#E2583E'}
          strokeWidth="7"
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          transform="rotate(-90 150 155)"
          className="transition-all duration-700 ease-out"
        />

        {/* Tomato Ground Shadow */}
        <ellipse cx="150" cy="272" rx="80" ry="12" fill="#000000" opacity="0.12" />

        {/* === TOMATO LEAVES & STEM (TOP) === */}
        <g id="tomato-stem-group">
          {/* Woody stem */}
          <path
            d="M150 48 Q152 24 164 16 Q168 18 165 24 Q156 34 154 50 Z"
            fill="#166534"
            stroke="#14532D"
            strokeWidth="1.2"
          />

          {/* Top leafy star sepals */}
          {/* Center-left leaf */}
          <path
            d="M150 56 Q130 38 108 42 Q124 58 142 62 Z"
            fill="url(#leaf-grad-1)"
          />
          {/* Far-left leaf */}
          <path
            d="M144 60 Q112 56 86 70 Q110 78 136 68 Z"
            fill="url(#leaf-grad-2)"
          />
          {/* Center-right leaf */}
          <path
            d="M150 56 Q170 38 192 42 Q176 58 158 62 Z"
            fill="url(#leaf-grad-1)"
          />
          {/* Far-right leaf */}
          <path
            d="M156 60 Q188 56 214 70 Q190 78 164 68 Z"
            fill="url(#leaf-grad-2)"
          />
          {/* Front small leaf */}
          <path
            d="M146 62 Q150 78 152 82 Q154 78 158 62 Z"
            fill="#15803D"
          />
        </g>

        {/* === MAIN TOMATO BODY === */}
        {/* Soft plump lobes of the tomato */}
        <g id="tomato-body" filter="url(#tomato-shadow)">
          {/* Left cheek lobe */}
          <ellipse cx="118" cy="162" rx="72" ry="78" fill="url(#tomato-body-grad)" />
          {/* Right cheek lobe */}
          <ellipse cx="182" cy="162" rx="72" ry="78" fill="url(#tomato-body-grad)" />
          {/* Central main body */}
          <ellipse cx="150" cy="165" rx="84" ry="80" fill="url(#tomato-body-grad)" />

          {/* Top indent where stem connects */}
          <path
            d="M125 78 Q150 94 175 78 Q150 86 125 78 Z"
            fill={isBreak ? '#065F46' : '#7F1D1D'}
            opacity="0.3"
          />

          {/* Glossy shine highlight on upper-left shoulder */}
          <path
            d="M100 102 C82 120 78 148 82 165 C76 150 78 128 92 110 C106 94 126 90 140 90 C122 92 108 96 100 102 Z"
            fill="white"
            opacity="0.32"
          />
          {/* Extra crisp specular highlight dot */}
          <circle cx="106" cy="116" r="6" fill="white" opacity="0.45" />

          {/* Clock Display Panel (Integrated into the Tomato Belly) */}
          <rect
            x="70"
            y="126"
            width="160"
            height="78"
            rx="24"
            fill="url(#clock-glass)"
            stroke="white"
            strokeWidth="1.5"
            strokeOpacity="0.4"
            className="backdrop-blur-sm"
          />
        </g>
      </svg>

      {/* HTML Digital Overlay on the Tomato Belly */}
      <div
        className="absolute inset-0 flex flex-col items-center justify-center text-center pointer-events-none"
        style={{ paddingTop: '28px' }}
      >
        {/* Mode Tag */}
        <span
          className={`font-semibold tracking-wider uppercase drop-shadow-sm text-white/90 ${dims.subSize} mb-0.5`}
        >
          {sessionType === 'focus'
            ? '🍅 專注時段'
            : sessionType === 'short_break'
            ? '☕ 短休息'
            : '🌿 長休息'}
        </span>

        {/* Time Display (Rendered ON THE TOMATO) */}
        <div
          className={`font-mono tracking-tight text-white font-extrabold drop-shadow-[0_2px_4px_rgba(0,0,0,0.35)] tabular-nums ${dims.fontSize}`}
        >
          {timeDisplay}
        </div>

        {/* Status ticker */}
        <span className={`text-white/80 font-medium ${dims.subSize} mt-0.5`}>
          {isRunning ? (
            <span className="inline-flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-white animate-ping" />
              計時進行中
            </span>
          ) : (
            '點擊以繼續'
          )}
        </span>
      </div>
    </div>
  );
};

export default TomatoGraphic;
