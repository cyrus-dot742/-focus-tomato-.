import React, { useState } from 'react';
import { ChevronLeft, Clock, CheckCircle2, Play, Calendar, TrendingUp, Plus, Trash2, Pencil, CalendarDays, AlertTriangle } from 'lucide-react';
import { Subject, Task, PomodoroSession, AppSettings } from '../types';
import { TomatoIcon } from './TomatoIcon';
import { getTodayStr, formatDateZh } from '../utils/dateUtils';
import { UNCATEGORIZED_SUBJECT_ID, UNCATEGORIZED_SUBJECT_NAME } from '../utils/subjectUtils';
import { formatDurationZh, formatDurationShort, getSessionSeconds } from '../utils/timeUtils';

interface SubjectDetailViewProps {
  subject: Subject;
  tasks: Task[];
  sessions: PomodoroSession[];
  settings: AppSettings;
  onBack: () => void;
  onStartFocus: (taskTitle: string, subjectId: string) => void;
  onAddTopicForSubject: (title: string, targetPomodoros: number, date: string) => void;
  onUpdateTask?: (taskId: string, updatedData: Partial<Task>) => void;
  onDeleteTask?: (taskId: string) => void;
  onDeleteSubject?: (id: string) => void;
}

export const SubjectDetailView: React.FC<SubjectDetailViewProps> = ({
  subject,
  tasks,
  sessions,
  settings,
  onBack,
  onStartFocus,
  onAddTopicForSubject,
  onUpdateTask,
  onDeleteTask,
  onDeleteSubject,
}) => {
  const todayStr = getTodayStr();
  const [chartMode, setChartMode] = useState<'week' | 'month'>('week');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [newTopicTitle, setNewTopicTitle] = useState('');
  const [newTargetPomodoros, setNewTargetPomodoros] = useState(3);
  const [newTopicDate, setNewTopicDate] = useState(todayStr);

  // Edit task state inside subject detail
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [editTargetPomodoros, setEditTargetPomodoros] = useState(1);
  const [editTaskDate, setEditTaskDate] = useState('');
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);

  const isUncategorized = subject.id === UNCATEGORIZED_SUBJECT_ID || subject.name === UNCATEGORIZED_SUBJECT_NAME;

  // Filter tasks & sessions strictly for this subject
  const subjectTasks = tasks.filter((t) => t.subjectId === subject.id);
  const subjectSessions = sessions.filter((s) => s.subjectId === subject.id);

  // Real aggregate calculations from actual sessions (precise to the second)
  const totalDurationSeconds = subjectSessions.reduce((acc, s) => acc + getSessionSeconds(s), 0);
  const totalDurationMinutes = Math.round(totalDurationSeconds / 60);
  // Check whether a session was a full Pomodoro:
  // Either marked isFull === true, or session ran for at least focusMinutes * 60 - 5 seconds
  const isSessionFull = (s: PomodoroSession) => {
    if (s.isFull !== undefined) return s.isFull;
    return getSessionSeconds(s) >= ((settings.focusMinutes || 25) * 60) - 5;
  };

  const fullSessionsCount = subjectSessions.filter(isSessionFull).length;
  const totalPomodoros = fullSessionsCount > 0 
    ? fullSessionsCount 
    : subjectTasks.reduce((acc, t) => acc + t.completedPomodoros, 0);

  // Format hours, minutes and seconds accurately (幾多分鐘幾多秒)
  const timeFormatted = formatDurationZh(totalDurationSeconds);

  // Merge unique topics from tasks & sessions
  interface TopicRecord {
    id: string;
    topicName: string;
    date: string;
    pomodoros: number;
    durationSeconds: number;
    status: 'completed' | 'in_progress';
    taskId?: string;
    targetPomodoros: number;
  }

  const topicRecords: TopicRecord[] = [];

  // 1. First, populate from master subjectTasks so every task shows up
  subjectTasks.forEach((t) => {
    const taskSessions = subjectSessions.filter(
      (s) => (s.taskId && s.taskId === t.id) || s.topicName === t.title
    );
    const recordedSecs = taskSessions.reduce((acc, s) => acc + getSessionSeconds(s), 0);
    const fulls = taskSessions.filter(isSessionFull).length;
    const taskSecs = t.actualSeconds !== undefined && t.actualSeconds > 0
      ? t.actualSeconds
      : (recordedSecs > 0 ? recordedSecs : (t.actualMinutes ? t.actualMinutes * 60 : 0));
    const effectivePomodoros = Math.max(t.completedPomodoros, fulls);

    topicRecords.push({
      id: t.id,
      topicName: t.title,
      date: t.date || todayStr,
      pomodoros: effectivePomodoros,
      durationSeconds: taskSecs,
      status: t.completed ? 'completed' : 'in_progress',
      taskId: t.id,
      targetPomodoros: t.targetPomodoros || 1,
    });
  });

  // 2. Also include any sessions that don't match any task in subjectTasks (e.g. quick sessions)
  subjectSessions.forEach((s) => {
    const matchedTask = subjectTasks.find(
      (t) => (s.taskId && s.taskId === t.id) || s.topicName === t.title
    );
    if (!matchedTask) {
      const existing = topicRecords.find((r) => r.topicName === s.topicName);
      const sessSecs = getSessionSeconds(s);
      const isFull = isSessionFull(s);
      if (existing) {
        if (isFull) existing.pomodoros += 1;
        existing.durationSeconds += sessSecs;
        if (s.date > existing.date) existing.date = s.date;
      } else {
        topicRecords.push({
          id: s.id,
          topicName: s.topicName,
          date: s.date,
          pomodoros: isFull ? 1 : 0,
          durationSeconds: sessSecs,
          status: 'completed',
          targetPomodoros: 1,
        });
      }
    }
  });

  // Sort descending by date (newest first)
  topicRecords.sort((a, b) => b.date.localeCompare(a.date));

  // Real Dynamic Chart Calculation (100% genuine data from subjectSessions)
  const now = new Date();
  
  // 1. Past 7 days (including today)
  const realWeekData = Array.from({ length: 7 }).map((_, i) => {
    const d = new Date(now);
    d.setDate(now.getDate() - (6 - i));
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    const dateStr = `${y}-${m}-${day}`;
    const shortDay = `${m}/${day}`;
    const weekdayLabels = ['日', '一', '二', '三', '四', '五', '六'];
    const label = weekdayLabels[d.getDay()];

    const daySessions = subjectSessions.filter((s) => s.date === dateStr);
    const secs = daySessions.reduce((acc, s) => acc + getSessionSeconds(s), 0);
    const mins = Math.round(secs / 60);

    return {
      dateStr,
      shortDay,
      label,
      secs,
      mins,
      isToday: dateStr === todayStr,
    };
  });

  // 2. Month data (4-5 weeks of current month)
  const currentMonthNum = now.getMonth() + 1;
  const currentYearNum = now.getFullYear();
  const daysInMonth = new Date(currentYearNum, currentMonthNum, 0).getDate();

  const realMonthData = [
    { label: '第1周', range: '1-7日', startDay: 1, endDay: 7 },
    { label: '第2周', range: '8-14日', startDay: 8, endDay: 14 },
    { label: '第3周', range: '15-21日', startDay: 15, endDay: 21 },
    { label: '第4周', range: '22-28日', startDay: 22, endDay: 28 },
    ...(daysInMonth > 28
      ? [{ label: '第5周', range: `29-${daysInMonth}日`, startDay: 29, endDay: daysInMonth }]
      : []),
  ].map((w) => {
    const weekSessions = subjectSessions.filter((s) => {
      const parts = s.date.split('-');
      if (parts.length !== 3) return false;
      const sY = parseInt(parts[0], 10);
      const sM = parseInt(parts[1], 10);
      const sD = parseInt(parts[2], 10);
      return sY === currentYearNum && sM === currentMonthNum && sD >= w.startDay && sD <= w.endDay;
    });
    const secs = weekSessions.reduce((acc, s) => acc + getSessionSeconds(s), 0);
    const mins = Math.round(secs / 60);
    return {
      label: w.label,
      subLabel: w.range,
      secs,
      mins,
      isToday:
        now.getDate() >= w.startDay &&
        now.getDate() <= w.endDay &&
        now.getMonth() + 1 === currentMonthNum,
    };
  });

  const chartData = chartMode === 'week' ? realWeekData : realMonthData;
  const totalChartSecs = chartData.reduce((acc, d) => acc + d.secs, 0);
  const totalChartMins = Math.round(totalChartSecs / 60);
  const maxChartSecs = Math.max(60, ...chartData.map((d) => d.secs));
  const peakChartSecs = Math.max(0, ...chartData.map((d) => d.secs));

  const handleAddTopic = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTopicTitle.trim()) return;
    onAddTopicForSubject(newTopicTitle.trim(), newTargetPomodoros, newTopicDate || todayStr);
    setNewTopicTitle('');
    setNewTopicDate(todayStr);
    setShowAddModal(false);
  };

  const handleConfirmDeleteSubject = () => {
    if (onDeleteSubject) {
      onDeleteSubject(subject.id);
    }
  };

  return (
    <div className="pb-24 px-4 pt-1 max-w-md mx-auto animate-in slide-in-from-right-4 duration-200">
      {/* Delete Subject Confirmation Modal */}
      {showDeleteModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/70 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-white dark:bg-stone-800 rounded-3xl p-6 max-w-xs w-full text-center shadow-2xl border border-stone-200 dark:border-stone-700 animate-in zoom-in-95 duration-150">
            <div className="w-12 h-12 rounded-full bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 mx-auto flex items-center justify-center mb-3">
              <AlertTriangle size={24} />
            </div>
            <h3 className="text-base font-bold text-stone-900 dark:text-white">
              確定要刪除科目「{subject.name}」？
            </h3>
            <p className="text-xs text-stone-500 dark:text-stone-400 mt-2 leading-relaxed text-left bg-stone-50 dark:bg-stone-900/60 p-3 rounded-xl border border-stone-200/60 dark:border-stone-700/60">
              📌 <strong>自動分類保護</strong>：刪除此科目後，所有已排定之主題與溫習歷史紀錄將會<strong>自動移至「未分類」科目</strong>，您的學習時長與歷程將完整保留。
            </p>
            <div className="flex gap-2.5 mt-5">
              <button
                type="button"
                onClick={() => setShowDeleteModal(false)}
                className="flex-1 py-2.5 text-xs font-semibold bg-stone-100 dark:bg-stone-700 text-stone-700 dark:text-stone-200 rounded-xl hover:bg-stone-200 dark:hover:bg-stone-600 transition-colors cursor-pointer"
              >
                取消
              </button>
              <button
                type="button"
                onClick={handleConfirmDeleteSubject}
                className="flex-1 py-2.5 text-xs font-bold bg-rose-600 hover:bg-rose-700 text-white rounded-xl shadow-xs transition-colors cursor-pointer"
              >
                確認刪除
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Top Navigation Bar */}
      <div className="flex items-center justify-between py-3 mb-1">
        <button
          onClick={onBack}
          className="flex items-center gap-1 -ml-1 text-sm font-semibold text-stone-600 dark:text-stone-300 hover:text-stone-900 dark:hover:text-white px-2 py-1.5 rounded-lg active:scale-95 transition-all cursor-pointer"
          type="button"
        >
          <ChevronLeft size={20} />
          <span>返回</span>
        </button>

        {/* Subject Title Lockup */}
        <div className="flex items-center gap-2">
          <span
            className="w-3 h-3 rounded-full shrink-0 shadow-xs"
            style={{ backgroundColor: subject.color }}
          />
          <h1 className="text-lg font-bold text-stone-900 dark:text-stone-100 truncate max-w-[140px]">
            {subject.name}
          </h1>
          {isUncategorized && (
            <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-stone-100 dark:bg-stone-700 text-stone-500 font-medium">
              未分類
            </span>
          )}
        </div>

        <div className="flex items-center gap-1">
          {/* Delete Subject Button (First requirement: 允許剷除科目) */}
          {onDeleteSubject && (
            <button
              onClick={() => setShowDeleteModal(true)}
              className="p-1.5 text-stone-400 hover:text-rose-500 dark:hover:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition-colors cursor-pointer"
              title={`刪除科目「${subject.name}」`}
              aria-label={`刪除科目 ${subject.name}`}
              type="button"
            >
              <Trash2 size={16} />
            </button>
          )}

          <button
            onClick={() => {
              setNewTopicDate(todayStr);
              setShowAddModal(true);
            }}
            className="flex items-center gap-1 text-xs font-bold text-[#E2583E] dark:text-orange-400 hover:underline px-2 py-1 cursor-pointer"
            type="button"
          >
            <Plus size={16} />
            <span>新主題</span>
          </button>
        </div>
      </div>

      {/* 科目總覽面板 (Subject Overview) */}
      <div className="bg-gradient-to-br from-white to-stone-50/60 dark:from-stone-800 dark:to-stone-800/60 rounded-3xl p-5 shadow-xs border border-stone-200/80 dark:border-stone-700/80">
        <div className="flex items-center justify-between pb-3 border-b border-stone-100 dark:border-stone-700">
          <div className="flex items-center gap-2">
            <span
              className="w-2.5 h-2.5 rounded-full"
              style={{ backgroundColor: subject.color }}
            />
            <span className="text-xs font-bold uppercase tracking-wider text-stone-500 dark:text-stone-400">
              科目真實數據
            </span>
          </div>
          <span className="text-[11px] font-medium text-stone-400">
            溫習歷程 (Study Tool)
          </span>
        </div>

        <div className="grid grid-cols-2 gap-4 mt-4">
          {/* 總完成蕃茄鐘數量 */}
          <div className="bg-white dark:bg-stone-900/60 p-3.5 rounded-2xl border border-stone-200/60 dark:border-stone-700/50">
            <div className="flex items-center gap-1.5 text-xs text-stone-500 dark:text-stone-400 mb-1">
              <TomatoIcon size={16} filled={totalPomodoros > 0} partial={totalPomodoros === 0 && totalDurationSeconds > 0} />
              <span>完整蕃茄</span>
            </div>
            <div className="flex items-baseline gap-1">
              <span className="text-2xl font-black text-stone-900 dark:text-stone-100 tabular-nums">
                {totalPomodoros}
              </span>
              <span className="text-xs font-semibold text-stone-500">個完整蕃茄</span>
            </div>
            <div className="text-[11px] text-stone-400 mt-0.5">
              累計專注 {timeFormatted}
            </div>
          </div>

          {/* 總溫習時長 (精確至秒，例：1分鐘25秒) */}
          <div className="bg-white dark:bg-stone-900/60 p-3.5 rounded-2xl border border-stone-200/60 dark:border-stone-700/50">
            <div className="flex items-center gap-1.5 text-xs text-stone-500 dark:text-stone-400 mb-1">
              <Clock size={15} className="text-orange-500" />
              <span>總溫習時長</span>
            </div>
            <div className="flex items-baseline gap-1">
              <span className="text-xl font-black text-stone-900 dark:text-stone-100 tabular-nums">
                {timeFormatted}
              </span>
            </div>
            <div className="text-[11px] text-stone-400 mt-0.5">
              已累積 {topicRecords.length} 個主題
            </div>
          </div>
        </div>
      </div>

      {/* 溫習時長趨勢圖 (Real dynamic trend chart from actual sessions) */}
      <div className="mt-4 bg-white dark:bg-stone-800 rounded-3xl p-5 shadow-xs border border-stone-200/80 dark:border-stone-700/80">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-1.5">
            <TrendingUp size={16} className="text-[#E2583E]" />
            <h3 className="text-sm font-bold text-stone-900 dark:text-stone-100">
              溫習時長趨勢
            </h3>
          </div>
          <div className="flex items-center gap-1 p-0.5 bg-stone-100 dark:bg-stone-700 rounded-lg text-xs font-medium">
            <button
              onClick={() => setChartMode('week')}
              type="button"
              className={`px-2.5 py-1 rounded-md transition-all cursor-pointer ${
                chartMode === 'week'
                  ? 'bg-white dark:bg-stone-800 text-stone-900 dark:text-white font-bold shadow-xs'
                  : 'text-stone-500 hover:text-stone-900 dark:text-stone-400 dark:hover:text-stone-200'
              }`}
            >
              本周
            </button>
            <button
              onClick={() => setChartMode('month')}
              type="button"
              className={`px-2.5 py-1 rounded-md transition-all cursor-pointer ${
                chartMode === 'month'
                  ? 'bg-white dark:bg-stone-800 text-stone-900 dark:text-white font-bold shadow-xs'
                  : 'text-stone-500 hover:text-stone-900 dark:text-stone-400 dark:hover:text-stone-200'
              }`}
            >
              本月
            </button>
          </div>
        </div>

        {/* Real Bar Chart Container */}
        <div className="h-32 flex items-end justify-between gap-2 pt-4 px-1 border-b border-stone-100 dark:border-stone-700 relative">
          {chartData.map((d, idx) => {
            const heightPercent = d.secs > 0 ? Math.max(12, (d.secs / maxChartSecs) * 100) : 4;
            const isHighlighted = d.isToday;

            return (
              <div
                key={idx}
                className="flex-1 flex flex-col items-center gap-1.5 h-full justify-end group cursor-pointer"
                title={`${d.label}: ${formatDurationZh(d.secs)} 溫習`}
              >
                {/* Value tooltip */}
                <div className={`transition-opacity text-[10px] font-bold -mb-1 ${
                  d.secs > 0 
                    ? 'text-stone-700 dark:text-stone-200 opacity-90' 
                    : 'text-stone-400 opacity-0 group-hover:opacity-100'
                }`}>
                  {d.secs > 0 ? formatDurationShort(d.secs) : '0s'}
                </div>

                {/* The Bar */}
                <div
                  className="w-full max-w-[28px] rounded-t-lg transition-all duration-500"
                  style={{
                    height: `${heightPercent}%`,
                    backgroundColor:
                      d.secs > 0
                        ? isHighlighted
                          ? subject.color
                          : `${subject.color}99`
                        : '#E7E5E4',
                  }}
                />

                {/* Day label */}
                <span
                  className={`text-[11px] font-medium truncate ${
                    isHighlighted
                      ? 'text-[#E2583E] font-bold'
                      : 'text-stone-400 dark:text-stone-500'
                  }`}
                >
                  {d.label}
                </span>
              </div>
            );
          })}
        </div>

        {/* Dynamic Summary Footnote */}
        <div className="flex items-center justify-between mt-2.5 text-[11px] text-stone-500 dark:text-stone-400 font-medium">
          <span>
            {chartMode === 'week' ? '本周總專注' : '本月總專注'}：
            <strong className="text-stone-800 dark:text-stone-200 ml-1">
              {formatDurationZh(totalChartSecs)}
            </strong>
          </span>
          <span>
            最高單{chartMode === 'week' ? '日' : '周'}：
            <strong className="text-stone-800 dark:text-stone-200 ml-1">
              {formatDurationZh(peakChartSecs)}
            </strong>
          </span>
        </div>

        {totalChartMins === 0 && (
          <div className="mt-2 p-2 bg-stone-50 dark:bg-stone-900/40 rounded-xl text-center text-[11px] text-stone-400">
            🌱 目前尚未有此科目的溫習紀錄。完成蕃茄鐘後，系統將實時自動記錄真實時長！
          </div>
        )}
      </div>

      {/* Topic (主題/任務) 歷史紀錄列表 */}
      <div className="mt-5">
        <div className="flex items-center justify-between mb-3 px-1">
          <h3 className="text-sm font-bold text-stone-900 dark:text-stone-100">
            Topic 主題溫習歷程 ({topicRecords.length})
          </h3>
          <span className="text-xs text-stone-400 font-medium">按時間倒序排列</span>
        </div>

        <div className="space-y-3">
          {topicRecords.length === 0 ? (
            <div className="text-center py-8 bg-white dark:bg-stone-800 rounded-2xl border border-stone-200/70 dark:border-stone-700/60 p-5">
              <CalendarDays className="w-9 h-9 text-stone-300 dark:text-stone-600 mx-auto mb-2" />
              <p className="text-sm font-semibold text-stone-600 dark:text-stone-300">
                尚未建立此科目的主題
              </p>
              <p className="text-xs text-stone-400 mt-1 max-w-xs mx-auto">
                點擊右上角「+ 新主題」設定特定日期的溫習主題，出邊主頁將在該日自動顯示！
              </p>
              <button
                onClick={() => {
                  setNewTopicDate(todayStr);
                  setShowAddModal(true);
                }}
                className="mt-3 inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#E2583E] text-white text-xs font-bold rounded-xl shadow-xs cursor-pointer"
                type="button"
              >
                <Plus size={14} />
                <span>立即建立主題</span>
              </button>
            </div>
          ) : (
            topicRecords.map((record) => {
              const isCompleted = record.status === 'completed';

              return (
                <div
                  key={record.id}
                  className="bg-white dark:bg-stone-800 rounded-2xl p-4 shadow-xs border border-stone-200/70 dark:border-stone-700/60 hover:border-orange-200 dark:hover:border-stone-600 transition-all"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      {/* Status Pill & Date */}
                      <div className="flex items-center gap-2 mb-1.5">
                        <span
                          className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            isCompleted
                              ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400'
                              : 'bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400'
                          }`}
                        >
                          {isCompleted ? (
                            <>
                              <CheckCircle2 size={11} />
                              已完成
                            </>
                          ) : (
                            <>
                              <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />
                              進行中
                            </>
                          )}
                        </span>

                        <span className="text-xs text-stone-400 flex items-center gap-1 font-mono">
                          <Calendar size={12} />
                          {record.date}
                        </span>
                      </div>

                      {/* Topic Title */}
                      <h4 className="text-sm font-bold text-stone-900 dark:text-stone-100 truncate">
                        {record.topicName}
                      </h4>

                      {/* Duration / Pomodoro Breakdown */}
                      <div className="flex items-center gap-3 mt-2 text-xs text-stone-500 dark:text-stone-400">
                        <div className="flex items-center gap-0.5 font-semibold text-stone-700 dark:text-stone-300">
                          {(() => {
                            const topicSessions = subjectSessions.filter(
                              (s) => (record.taskId && s.taskId === record.taskId) || s.topicName === record.topicName && s.type === 'focus'
                            );
                            const totalRecorded = topicSessions.length;
                            const fulls = topicSessions.filter(isSessionFull).length;
                            const partials = Math.max(0, totalRecorded - fulls);
                            const effectiveFull = Math.max(record.pomodoros, fulls);
                            const effectiveTotal = Math.max(effectiveFull + partials, totalRecorded);
                            const slots = Math.max(record.targetPomodoros || 1, effectiveTotal, 1);

                            return Array.from({ length: slots }).map((_, i) => {
                              const isFull = i < effectiveFull;
                              const isPartial = !isFull && i < effectiveTotal;
                              return (
                                <TomatoIcon
                                  key={i}
                                  size={14}
                                  filled={isFull}
                                  partial={isPartial}
                                />
                              );
                            });
                          })()}
                        </div>
                        <span className="text-stone-300 dark:text-stone-600">•</span>
                        <span className="font-semibold text-stone-800 dark:text-stone-200">
                          用咗 {formatDurationZh(record.durationSeconds)}
                        </span>
                      </div>
                    </div>

                    {/* Action Buttons: Play, Edit, Delete */}
                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        onClick={() => onStartFocus(record.topicName, subject.id)}
                        className="w-8 h-8 rounded-full bg-orange-50 dark:bg-stone-700 hover:bg-orange-100 dark:hover:bg-stone-600 text-[#E2583E] dark:text-orange-400 flex items-center justify-center transition-colors active:scale-95 shadow-xs cursor-pointer"
                        title="開始溫習此主題"
                        aria-label="開始溫習此主題"
                        type="button"
                      >
                        <Play size={14} className="ml-0.5 fill-current" />
                      </button>

                      {record.taskId && (
                        <>
                          <button
                            onClick={() => {
                              const foundTask = subjectTasks.find((t) => t.id === record.taskId);
                              if (foundTask) {
                                setEditingTask(foundTask);
                                setEditTitle(foundTask.title);
                                setEditTargetPomodoros(foundTask.targetPomodoros);
                                setEditTaskDate(foundTask.date || todayStr);
                                setIsEditModalOpen(true);
                              }
                            }}
                            className="w-8 h-8 rounded-full flex items-center justify-center text-stone-500 hover:text-stone-800 dark:text-stone-400 dark:hover:text-stone-100 bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 transition-colors cursor-pointer shadow-2xs"
                            title="編輯主題"
                            aria-label="編輯主題"
                            type="button"
                          >
                            <Pencil size={13} />
                          </button>

                          <button
                            onClick={() => {
                              if (onDeleteTask && record.taskId) {
                                onDeleteTask(record.taskId);
                              }
                            }}
                            className="w-8 h-8 rounded-full flex items-center justify-center text-rose-500 hover:text-rose-700 dark:text-rose-400 dark:hover:text-rose-300 bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 transition-colors cursor-pointer shadow-2xs"
                            title="刪除主題"
                            aria-label="刪除主題"
                            type="button"
                          >
                            <Trash2 size={13} />
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Edit Task Modal in Subject Detail */}
      {isEditModalOpen && editingTask && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white dark:bg-stone-800 rounded-3xl p-6 w-full max-w-sm shadow-2xl border border-stone-200/80 dark:border-stone-700">
            <h3 className="text-base font-bold text-stone-900 dark:text-stone-100 mb-1">
              編輯溫習主題
            </h3>
            <p className="text-xs text-stone-500 dark:text-stone-400 mb-4">
              修改主題名稱、預定日期或目標蕃茄鐘（與今日主頁完全同步）。
            </p>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (!editTitle.trim() || !onUpdateTask || !editingTask) return;
                onUpdateTask(editingTask.id, {
                  title: editTitle.trim(),
                  targetPomodoros: editTargetPomodoros,
                  date: editTaskDate,
                });
                setIsEditModalOpen(false);
                setEditingTask(null);
              }}
              className="space-y-4"
            >
              <div>
                <label className="block text-xs font-semibold text-stone-600 dark:text-stone-300 mb-1.5">
                  主題名稱 (Topic)
                </label>
                <input
                  type="text"
                  required
                  value={editTitle}
                  onChange={(e) => setEditTitle(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-stone-50 dark:bg-stone-900 border border-stone-200 dark:border-stone-700 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#E2583E] dark:text-white"
                  autoFocus
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-600 dark:text-stone-300 mb-1.5">
                  預定溫習日期
                </label>
                <input
                  type="date"
                  required
                  value={editTaskDate}
                  onChange={(e) => setEditTaskDate(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-900 border border-stone-200 dark:border-stone-700 rounded-xl text-xs font-semibold text-stone-800 dark:text-stone-200 focus:outline-none focus:ring-2 focus:ring-[#E2583E] cursor-pointer"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-600 dark:text-stone-300 mb-1.5">
                  目標蕃茄鐘數量
                </label>
                <div className="flex items-center gap-2">
                  {[1, 2, 3, 4, 5].map((num) => (
                    <button
                      type="button"
                      key={num}
                      onClick={() => setEditTargetPomodoros(num)}
                      className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all flex flex-col items-center gap-0.5 cursor-pointer ${
                        editTargetPomodoros === num
                          ? 'bg-[#E2583E] text-white shadow-xs'
                          : 'bg-stone-100 dark:bg-stone-700 text-stone-700 dark:text-stone-300 hover:bg-stone-200 dark:hover:bg-stone-600'
                      }`}
                    >
                      <TomatoIcon size={14} filled={editTargetPomodoros === num} />
                      <span>{num} 個</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="pt-2 flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setIsEditModalOpen(false);
                    setEditingTask(null);
                  }}
                  className="flex-1 py-2.5 text-xs font-semibold text-stone-600 dark:text-stone-300 bg-stone-100 dark:bg-stone-700 rounded-xl hover:bg-stone-200 dark:hover:bg-stone-600 transition-colors cursor-pointer"
                >
                  取消
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 text-xs font-bold text-white bg-[#E2583E] hover:bg-[#D1492F] rounded-xl shadow-md shadow-orange-500/25 transition-all cursor-pointer"
                >
                  儲存修改
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: 建立溫習主題 (可自訂 年/月/日) */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white dark:bg-stone-800 rounded-3xl p-6 w-full max-w-sm shadow-2xl border border-stone-200/80 dark:border-stone-700">
            <h3 className="text-base font-bold text-stone-900 dark:text-stone-100 mb-1">
              為「{subject.name}」建立溫習主題
            </h3>
            <p className="text-xs text-stone-500 dark:text-stone-400 mb-4">
              設定溫習主題與具體日期，出邊主頁面只會在當日顯示！
            </p>

            <form onSubmit={handleAddTopic} className="space-y-4">
              {/* Topic Title */}
              <div>
                <label className="block text-xs font-semibold text-stone-600 dark:text-stone-300 mb-1.5">
                  主題名稱 (Topic)
                </label>
                <input
                  type="text"
                  required
                  placeholder="例：微積分常微分方程"
                  value={newTopicTitle}
                  onChange={(e) => setNewTopicTitle(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-stone-50 dark:bg-stone-900 border border-stone-200 dark:border-stone-700 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#E2583E] dark:text-white"
                  autoFocus
                />
              </div>

              {/* Specific Date Picker (Year, Month, Day) */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-semibold text-stone-600 dark:text-stone-300 flex items-center gap-1">
                    <Calendar size={13} className="text-[#E2583E]" />
                    <span>預定溫習日期 (年/月/日)</span>
                  </label>
                  <span className="text-[10px] text-stone-400">
                    出邊僅於該日顯示
                  </span>
                </div>
                
                <input
                  type="date"
                  required
                  value={newTopicDate}
                  onChange={(e) => setNewTopicDate(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-900 border border-stone-200 dark:border-stone-700 rounded-xl text-xs font-semibold text-stone-800 dark:text-stone-200 focus:outline-none focus:ring-2 focus:ring-[#E2583E] cursor-pointer"
                />

                {/* Quick Date buttons */}
                <div className="flex items-center gap-2 mt-2">
                  <button
                    type="button"
                    onClick={() => setNewTopicDate(todayStr)}
                    className={`flex-1 py-1 rounded-lg text-[11px] font-semibold border transition-all cursor-pointer ${
                      newTopicDate === todayStr
                        ? 'border-[#E2583E] bg-orange-50 dark:bg-orange-950/40 text-[#E2583E]'
                        : 'border-stone-200 dark:border-stone-700 text-stone-600 dark:text-stone-400 hover:bg-stone-100 dark:hover:bg-stone-700'
                    }`}
                  >
                    今天
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const tomorrow = new Date();
                      tomorrow.setDate(tomorrow.getDate() + 1);
                      const tY = tomorrow.getFullYear();
                      const tM = String(tomorrow.getMonth() + 1).padStart(2, '0');
                      const tD = String(tomorrow.getDate()).padStart(2, '0');
                      setNewTopicDate(`${tY}-${tM}-${tD}`);
                    }}
                    className="flex-1 py-1 rounded-lg text-[11px] font-semibold border border-stone-200 dark:border-stone-700 text-stone-600 dark:text-stone-400 hover:bg-stone-100 dark:hover:bg-stone-700 transition-all cursor-pointer"
                  >
                    明天
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const after = new Date();
                      after.setDate(after.getDate() + 2);
                      const aY = after.getFullYear();
                      const aM = String(after.getMonth() + 1).padStart(2, '0');
                      const aD = String(after.getDate()).padStart(2, '0');
                      setNewTopicDate(`${aY}-${aM}-${aD}`);
                    }}
                    className="flex-1 py-1 rounded-lg text-[11px] font-semibold border border-stone-200 dark:border-stone-700 text-stone-600 dark:text-stone-400 hover:bg-stone-100 dark:hover:bg-stone-700 transition-all cursor-pointer"
                  >
                    後天
                  </button>
                </div>

                <p className="text-[11px] text-stone-400 mt-1.5">
                  已選定：{formatDateZh(newTopicDate)}
                </p>
              </div>

              {/* Target Pomodoros */}
              <div>
                <label className="block text-xs font-semibold text-stone-600 dark:text-stone-300 mb-1.5">
                  預計目標蕃茄數 (每個 {settings.focusMinutes} 分鐘)
                </label>
                <div className="flex gap-2">
                  {[1, 2, 3, 4, 5].map((num) => (
                    <button
                      type="button"
                      key={num}
                      onClick={() => setNewTargetPomodoros(num)}
                      className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all flex flex-col items-center gap-0.5 cursor-pointer ${
                        newTargetPomodoros === num
                          ? 'bg-[#E2583E] text-white shadow-xs'
                          : 'bg-stone-100 dark:bg-stone-700 text-stone-700 dark:text-stone-300'
                      }`}
                    >
                      <TomatoIcon size={13} filled={newTargetPomodoros === num} />
                      <span>{num} 個</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="pt-2 flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 py-2.5 text-xs font-semibold text-stone-600 dark:text-stone-300 bg-stone-100 dark:bg-stone-700 rounded-xl hover:bg-stone-200 dark:hover:bg-stone-600 cursor-pointer"
                >
                  取消
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 text-xs font-bold text-white bg-[#E2583E] hover:bg-[#D1492F] rounded-xl shadow-md shadow-orange-500/25 cursor-pointer"
                >
                  確認建立
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
