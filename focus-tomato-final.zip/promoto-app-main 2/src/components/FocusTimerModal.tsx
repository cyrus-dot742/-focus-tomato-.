import React, { useState } from 'react';
import { Play, Pause, RotateCcw, CheckCircle2, ChevronDown, Trash2, X } from 'lucide-react';
import { TomatoGraphic } from './TomatoGraphic';
import { TomatoIcon } from './TomatoIcon';
import { Task, Subject, AppSettings, PomodoroSession } from '../types';

interface FocusTimerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onMinimize: () => void;
  task?: Task;
  subject?: Subject;
  allTasks: Task[];
  sessions?: PomodoroSession[];
  onSelectTask: (task: Task) => void;
  timeLeft: number;
  totalDuration: number;
  isRunning: boolean;
  sessionType: 'focus' | 'short_break' | 'long_break';
  settings: AppSettings;
  onToggleTimer: () => void;
  onResetTimer: () => void;
  onDiscardTimer: () => void;
  onCompletePomodoro: () => void;
  onChangeSessionType: (type: 'focus' | 'short_break' | 'long_break') => void;
  isAlarmRinging?: boolean;
  onStopAlarm?: () => void;
}

export const FocusTimerModal: React.FC<FocusTimerModalProps> = ({
  isOpen,
  onClose,
  onMinimize,
  task,
  subject,
  allTasks,
  sessions = [],
  onSelectTask,
  timeLeft,
  totalDuration,
  isRunning,
  sessionType,
  settings,
  onToggleTimer,
  onResetTimer,
  onDiscardTimer,
  onCompletePomodoro,
  onChangeSessionType,
  isAlarmRinging,
  onStopAlarm,
}) => {
  const [showTaskSelector, setShowTaskSelector] = useState(false);
  const [showDiscardConfirm, setShowDiscardConfirm] = useState(false);

  if (!isOpen) return null;

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  const timeDisplay = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
  const progressPercent = totalDuration > 0 ? (timeLeft / totalDuration) * 100 : 0;
  const hasStarted = isRunning || timeLeft < totalDuration;

  const handleDiscardClick = () => {
    setShowDiscardConfirm(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-stone-900/70 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-stone-50 dark:bg-stone-900 rounded-3xl shadow-2xl border border-stone-200/80 dark:border-stone-800 overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Alarm Ringing Banner Inside Modal */}
        {isAlarmRinging && (
          <div className="bg-rose-600 text-white px-4 py-2.5 flex items-center justify-between shadow-md animate-bounce shrink-0">
            <div className="flex items-center gap-2">
              <span className="text-lg">🔔</span>
              <span className="text-xs font-bold">時間到！提示音持續響起中</span>
            </div>
            {onStopAlarm && (
              <button
                type="button"
                onClick={onStopAlarm}
                className="px-3 py-1.5 bg-white text-rose-600 hover:bg-rose-50 font-bold rounded-xl text-xs active:scale-95 transition-all shadow-sm cursor-pointer"
              >
                關閉提示音 (Stop)
              </button>
            )}
          </div>
        )}
        
        {/* Custom In-Modal Discard Confirmation (Zero window.confirm, 100% works in iframes) */}
        {showDiscardConfirm && (
          <div className="absolute inset-0 z-50 flex items-center justify-center p-6 bg-stone-950/80 backdrop-blur-xs animate-in fade-in duration-150">
            <div className="bg-white dark:bg-stone-800 rounded-2xl p-5 max-w-xs w-full text-center shadow-2xl border border-stone-200 dark:border-stone-700 animate-in zoom-in-95 duration-150">
              <div className="w-12 h-12 rounded-full bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 mx-auto flex items-center justify-center mb-3">
                <Trash2 size={22} />
              </div>
              <h4 className="text-base font-bold text-stone-900 dark:text-white">
                放棄並刪除本次計時？
              </h4>
              <p className="text-xs text-stone-500 dark:text-stone-400 mt-1.5 leading-relaxed">
                本次溫習計時將直接刪除，<strong className="text-rose-600 dark:text-rose-400 font-semibold">不會記錄</strong>任何溫習時間，亦不會計入科目歷程。
              </p>
              <div className="flex gap-2.5 mt-5">
                <button
                  type="button"
                  onClick={() => setShowDiscardConfirm(false)}
                  className="flex-1 py-2 text-xs font-semibold bg-stone-100 dark:bg-stone-700 text-stone-700 dark:text-stone-200 rounded-xl hover:bg-stone-200 dark:hover:bg-stone-600 transition-colors cursor-pointer"
                >
                  繼續專注
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowDiscardConfirm(false);
                    onDiscardTimer();
                  }}
                  className="flex-1 py-2 text-xs font-bold bg-rose-600 hover:bg-rose-700 text-white rounded-xl shadow-xs transition-colors cursor-pointer"
                >
                  確認刪除
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Top Header Actions */}
        <div className="flex items-center justify-between px-5 pt-4 pb-2">
          <button
            onClick={onMinimize}
            className="flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-stone-600 dark:text-stone-300 hover:text-stone-900 dark:hover:text-white bg-stone-200/60 dark:bg-stone-800 rounded-full transition-colors active:scale-95 cursor-pointer"
            type="button"
          >
            <ChevronDown size={16} />
            <span>縮小</span>
          </button>

          {/* Mode Pill Badges */}
          <div className="flex items-center gap-1 p-1 bg-stone-200/70 dark:bg-stone-800 rounded-xl text-xs font-medium">
            <button
              onClick={() => onChangeSessionType('focus')}
              className={`px-3 py-1 rounded-lg transition-all cursor-pointer ${
                sessionType === 'focus'
                  ? 'bg-white dark:bg-stone-700 text-orange-600 dark:text-orange-400 font-bold shadow-xs'
                  : 'text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-white'
              }`}
              type="button"
            >
              專注 {settings.focusMinutes}m
            </button>
            <button
              onClick={() => onChangeSessionType('short_break')}
              className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                sessionType === 'short_break'
                  ? 'bg-white dark:bg-stone-700 text-emerald-600 dark:text-emerald-400 font-bold shadow-xs'
                  : 'text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-white'
              }`}
              type="button"
            >
              短休 {settings.shortBreakMinutes}m
            </button>
            <button
              onClick={() => onChangeSessionType('long_break')}
              className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                sessionType === 'long_break'
                  ? 'bg-white dark:bg-stone-700 text-teal-600 dark:text-teal-400 font-bold shadow-xs'
                  : 'text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-white'
              }`}
              type="button"
            >
              長休 {settings.longBreakMinutes}m
            </button>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center rounded-full text-stone-400 hover:text-stone-600 dark:hover:text-stone-200 hover:bg-stone-200/50 dark:hover:bg-stone-800 transition-colors cursor-pointer"
            type="button"
            aria-label="關閉"
          >
            <X size={18} />
          </button>
        </div>

        {/* Center: The Tomato Graphic with Time right on it */}
        <div className="flex-1 flex flex-col items-center justify-center px-6 py-4">
          <div className="my-2 cursor-pointer active:scale-98 transition-transform" onClick={onToggleTimer}>
            <TomatoGraphic
              timeDisplay={timeDisplay}
              isRunning={isRunning}
              progressPercent={progressPercent}
              sessionType={sessionType}
              size="lg"
            />
          </div>

          {/* Current Task Details */}
          <div className="mt-2 text-center w-full max-w-sm">
            <div className="inline-flex items-center gap-2 mb-1">
              {subject ? (
                <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-white dark:bg-stone-800 shadow-xs border border-stone-200/70 dark:border-stone-700">
                  <span
                    className="w-2.5 h-2.5 rounded-full"
                    style={{ backgroundColor: subject.color }}
                  />
                  <span className="text-stone-700 dark:text-stone-200">{subject.name}</span>
                </span>
              ) : (
                <span className="text-xs text-stone-400">自主專注</span>
              )}
            </div>

            <div className="relative">
              <button
                onClick={() => setShowTaskSelector(!showTaskSelector)}
                className="inline-flex items-center justify-center gap-1 text-base font-bold text-stone-900 dark:text-stone-100 hover:text-orange-600 dark:hover:text-orange-400 transition-colors max-w-full px-2 py-1 rounded-lg hover:bg-stone-200/50 dark:hover:bg-stone-800 cursor-pointer"
                type="button"
              >
                <span className="truncate">{task ? task.title : '自主學習溫習'}</span>
                <ChevronDown size={14} className="text-stone-400 shrink-0" />
              </button>

              {/* Task Selector Dropdown */}
              {showTaskSelector && (
                <div className="absolute left-1/2 -translate-x-1/2 mt-2 w-72 bg-white dark:bg-stone-800 rounded-2xl shadow-xl border border-stone-200 dark:border-stone-700 p-2 z-20 max-h-52 overflow-y-auto text-left">
                  <div className="text-[11px] font-bold text-stone-400 px-3 py-1 uppercase tracking-wider">
                    選擇溫習任務 / Topic
                  </div>
                  {allTasks.length === 0 ? (
                    <div className="text-xs text-stone-400 px-3 py-2">目前沒有未完成的任務</div>
                  ) : (
                    allTasks.map((t) => (
                      <button
                        key={t.id}
                        onClick={() => {
                          onSelectTask(t);
                          setShowTaskSelector(false);
                        }}
                        className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs text-left transition-colors cursor-pointer ${
                          task?.id === t.id
                            ? 'bg-orange-50 dark:bg-orange-950/40 text-orange-600 dark:text-orange-400 font-bold'
                            : 'hover:bg-stone-100 dark:hover:bg-stone-700/60 text-stone-700 dark:text-stone-300'
                        }`}
                        type="button"
                      >
                        <span className="truncate pr-2">{t.title}</span>
                        <span className="text-[10px] text-stone-400 font-mono shrink-0">
                          {t.completedPomodoros}/{t.targetPomodoros}
                        </span>
                      </button>
                    ))
                  )}
                </div>
              )}
            </div>

            {/* Target Pomodoros Tracker if task exists */}
            {task && (() => {
              const taskSessions = sessions.filter(
                (s) => s.taskId === task.id || (s.topicName === task.title && s.date === task.date)
              );
              const focusSessions = taskSessions.filter((s) => s.type === 'focus');
              const totalRecordedSessions = focusSessions.length;
              const fullPomodoros = focusSessions.filter((s) => s.isFull).length;
              const partialPomodoros = Math.max(0, totalRecordedSessions - fullPomodoros);
              const effectiveFullCount = Math.max(task.completedPomodoros, fullPomodoros);
              const effectiveTotalCount = Math.max(effectiveFullCount + partialPomodoros, totalRecordedSessions);
              const totalSlots = Math.max(task.targetPomodoros, effectiveTotalCount, 1);

              return (
                <div className="flex items-center justify-center gap-1.5 mt-2">
                  <div className="flex items-center gap-0.5">
                    {Array.from({ length: totalSlots }).map((_, i) => {
                      const isFull = i < effectiveFullCount;
                      const isPartial = !isFull && i < effectiveTotalCount;
                      return (
                        <TomatoIcon
                          key={i}
                          size={15}
                          filled={isFull}
                          partial={isPartial}
                        />
                      );
                    })}
                  </div>
                  <span className="text-xs font-mono text-stone-500 dark:text-stone-400 ml-1">
                    ({effectiveTotalCount}/{task.targetPomodoros} 次專注)
                  </span>
                </div>
              );
            })()}
          </div>
        </div>

        {/* Bottom Control Bar */}
        <div className="px-5 py-4 bg-white dark:bg-stone-800/90 border-t border-stone-200/80 dark:border-stone-800 flex items-center justify-between gap-2">
          {/* Main Action Buttons depending on sessionType */}
          {sessionType === 'focus' ? (
            <>
              {/* Reset button */}
              <button
                onClick={onResetTimer}
                className="flex flex-col items-center gap-1 text-stone-500 hover:text-stone-700 dark:text-stone-400 dark:hover:text-stone-200 transition-colors p-2 active:scale-95 cursor-pointer"
                title="重設計時器"
                type="button"
              >
                <RotateCcw size={19} />
                <span className="text-[10px] font-medium">重設</span>
              </button>

              {/* Delete / Discard Clock Button (Won't be recorded!) */}
              <button
                onClick={handleDiscardClick}
                className={`flex flex-col items-center gap-1 p-2 rounded-xl transition-all active:scale-95 cursor-pointer ${
                  hasStarted
                    ? 'text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 opacity-100'
                    : 'text-stone-400 dark:text-stone-600 opacity-60 hover:opacity-100'
                }`}
                title="刪除本次計時（不會被記錄）"
                type="button"
              >
                <Trash2 size={19} />
                <span className="text-[10px] font-medium">刪除計時</span>
              </button>

              {/* Main Play / Pause Button */}
              <button
                onClick={onToggleTimer}
                className="px-6 py-3 bg-gradient-to-r from-orange-500 to-[#E2583E] hover:from-orange-600 hover:to-[#D1492F] text-white font-bold rounded-2xl shadow-lg shadow-orange-500/25 flex items-center gap-2 active:scale-95 transition-all text-sm sm:text-base cursor-pointer"
                type="button"
              >
                {isRunning ? (
                  <>
                    <Pause size={18} />
                    <span>暫停專注</span>
                  </>
                ) : (
                  <>
                    <Play size={18} className="fill-white" />
                    <span>開始專注</span>
                  </>
                )}
              </button>

              {/* Complete / Record tomato button */}
              <button
                onClick={onCompletePomodoro}
                className="flex flex-col items-center gap-1 text-emerald-600 dark:text-emerald-400 hover:text-emerald-700 dark:hover:text-emerald-300 transition-colors p-2 active:scale-95 cursor-pointer"
                title={timeLeft <= 1 ? "完成此蕃茄鐘並記錄" : "提早結算並記錄實際時長 (未達完整蕃茄)"}
                type="button"
              >
                <CheckCircle2 size={20} />
                <span className="text-[10px] font-medium">
                  {timeLeft <= 1 ? "完成蕃茄" : "提早結算"}
                </span>
              </button>
            </>
          ) : (
            <>
              {/* Break mode controls */}
              <button
                onClick={() => onChangeSessionType('focus')}
                className="flex-1 py-3 px-3 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 font-bold rounded-2xl text-xs flex items-center justify-center gap-1.5 active:scale-95 transition-all cursor-pointer"
                type="button"
              >
                <span>跳過休息，開始下一個蕃茄 🍅</span>
              </button>

              <button
                onClick={onToggleTimer}
                className="px-4 py-3 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-bold rounded-2xl shadow-md flex items-center gap-2 active:scale-95 transition-all text-xs cursor-pointer"
                type="button"
              >
                {isRunning ? (
                  <>
                    <Pause size={16} />
                    <span>暫停休息</span>
                  </>
                ) : (
                  <>
                    <Play size={16} className="fill-white" />
                    <span>開始休息</span>
                  </>
                )}
              </button>

              <button
                onClick={onClose}
                className="px-3 py-3 bg-stone-200/70 dark:bg-stone-800 text-stone-700 dark:text-stone-300 font-semibold rounded-2xl text-xs hover:bg-stone-300 dark:hover:bg-stone-700 transition-colors active:scale-95 cursor-pointer"
                type="button"
              >
                縮小
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
