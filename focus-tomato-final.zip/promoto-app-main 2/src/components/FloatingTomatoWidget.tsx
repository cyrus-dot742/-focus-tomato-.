import React, { useState, useEffect } from 'react';
import { Play, Pause, Maximize2, Trash2, X, Check } from 'lucide-react';
import { TomatoGraphic } from './TomatoGraphic';

interface FloatingTomatoWidgetProps {
  timeDisplay: string;
  isRunning: boolean;
  progressPercent: number;
  sessionType: 'focus' | 'short_break' | 'long_break';
  taskTitle?: string;
  subjectName?: string;
  subjectColor?: string;
  onExpand: () => void;
  onTogglePlay: () => void;
  onDiscard: () => void;
  onComplete?: () => void;
}

export const FloatingTomatoWidget: React.FC<FloatingTomatoWidgetProps> = ({
  timeDisplay,
  isRunning,
  progressPercent,
  sessionType,
  taskTitle,
  subjectName,
  subjectColor = '#E2583E',
  onExpand,
  onTogglePlay,
  onDiscard,
  onComplete,
}) => {
  const [isConfirmingDiscard, setIsConfirmingDiscard] = useState(false);

  // Auto revert confirm state after 4 seconds of inactivity
  useEffect(() => {
    if (isConfirmingDiscard) {
      const timer = setTimeout(() => {
        setIsConfirmingDiscard(false);
      }, 4000);
      return () => clearTimeout(timer);
    }
  }, [isConfirmingDiscard]);

  const handleDiscardConfirm = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsConfirmingDiscard(false);
    onDiscard();
  };

  const handleDiscardCancel = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsConfirmingDiscard(false);
  };

  const handleTrashClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsConfirmingDiscard(true);
  };

  return (
    <div className="fixed bottom-20 right-4 z-40 flex items-center gap-2 p-2 pl-3 bg-white dark:bg-stone-800 rounded-full shadow-2xl border border-stone-200/80 dark:border-stone-700 animate-in slide-in-from-bottom-6 duration-300">
      <button
        onClick={onExpand}
        className="flex items-center gap-2 text-left focus:outline-none group cursor-pointer"
        type="button"
      >
        <div className="relative">
          <TomatoGraphic
            timeDisplay={timeDisplay}
            isRunning={isRunning}
            progressPercent={progressPercent}
            sessionType={sessionType}
            size="sm"
            className="w-11 h-11 pointer-events-none"
          />
        </div>
        <div className="flex flex-col pr-1 max-w-[110px]">
          <div className="flex items-center gap-1.5">
            <span
              className="w-2 h-2 rounded-full shrink-0"
              style={{ backgroundColor: subjectColor }}
            />
            <span className="text-[11px] font-semibold text-stone-500 dark:text-stone-400 truncate">
              {subjectName || '專注中'}
            </span>
          </div>
          <span className="text-xs font-bold text-stone-900 dark:text-stone-100 truncate">
            {taskTitle || '未指定主題'}
          </span>
        </div>
      </button>

      <div className="flex items-center gap-1 pl-1 border-l border-stone-200 dark:border-stone-700">
        {/* Play/Pause Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onTogglePlay();
          }}
          className="w-8 h-8 flex items-center justify-center rounded-full bg-orange-50 dark:bg-stone-700 text-orange-600 dark:text-orange-400 hover:bg-orange-100 dark:hover:bg-stone-600 active:scale-95 transition-transform cursor-pointer"
          aria-label={isRunning ? '暫停計時' : '開始計時'}
          type="button"
        >
          {isRunning ? <Pause size={15} /> : <Play size={15} className="ml-0.5" />}
        </button>

        {/* Complete Button (提早完成任務) */}
        {onComplete && (
          <button
            onClick={(e) => {
              e.stopPropagation();
              onComplete();
            }}
            className="w-8 h-8 flex items-center justify-center rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 active:scale-95 transition-transform cursor-pointer"
            title="Complete (提早完成任務並記錄實際秒數)"
            aria-label="提早完成任務"
            type="button"
          >
            <Check size={16} strokeWidth={2.5} />
          </button>
        )}

        {/* In-widget discard button / confirmation */}
        {isConfirmingDiscard ? (
          <div className="flex items-center gap-1 bg-rose-50 dark:bg-rose-950/80 px-2 py-1 rounded-full border border-rose-300 dark:border-rose-700 animate-in fade-in duration-150">
            <button
              onClick={handleDiscardConfirm}
              className="px-2 py-1 text-[11px] font-bold bg-rose-600 hover:bg-rose-700 text-white rounded-full active:scale-95 transition-all shadow-xs flex items-center gap-1 cursor-pointer"
              title="確認放棄並刪除本次計時 (不記錄)"
              type="button"
            >
              <Trash2 size={12} />
              <span>確認刪除</span>
            </button>
            <button
              onClick={handleDiscardCancel}
              className="w-5 h-5 flex items-center justify-center rounded-full text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 transition-colors cursor-pointer"
              title="取消"
              type="button"
            >
              <X size={12} />
            </button>
          </div>
        ) : (
          <button
            onClick={handleTrashClick}
            className="w-8 h-8 flex items-center justify-center rounded-full text-rose-500 hover:text-rose-700 dark:hover:text-rose-300 hover:bg-rose-50 dark:hover:bg-rose-950/40 active:scale-95 transition-colors cursor-pointer"
            title="刪除本次計時 (不記錄任何數據)"
            aria-label="刪除本次計時"
            type="button"
          >
            <Trash2 size={15} />
          </button>
        )}

        <button
          onClick={(e) => {
            e.stopPropagation();
            onExpand();
          }}
          className="w-8 h-8 flex items-center justify-center rounded-full text-stone-400 hover:text-stone-600 dark:hover:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-700 transition-colors cursor-pointer"
          aria-label="放大蕃茄鐘"
          type="button"
        >
          <Maximize2 size={14} />
        </button>
      </div>
    </div>
  );
};
