import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Plus, Check, Play, Trash2, Pencil, Calendar as CalendarIcon, X, CalendarDays, ArrowLeft, Clock } from 'lucide-react';
import { Task, Subject, PomodoroSession, AppSettings } from '../types';
import { TomatoIcon } from './TomatoIcon';
import { getTodayStr, formatDateZh } from '../utils/dateUtils';
import { UNCATEGORIZED_SUBJECT_ID, UNCATEGORIZED_SUBJECT_NAME } from '../utils/subjectUtils';
import { formatDurationZh, getSessionSeconds } from '../utils/timeUtils';

interface TodayViewProps {
  tasks: Task[];
  subjects: Subject[];
  sessions?: PomodoroSession[];
  settings: AppSettings;
  selectedDate: string; // YYYY-MM-DD
  onSelectDate: (date: string) => void;
  onToggleTaskComplete: (taskId: string) => void;
  onAddTask: (newTask: Omit<Task, 'id' | 'createdAt' | 'completed' | 'completedPomodoros'>) => void;
  onUpdateTask?: (taskId: string, updatedData: Partial<Task>) => void;
  onDeleteTask: (taskId: string) => void;
  onStartFocusForTask: (task: Task) => void;
  onNavigateToSubjects?: () => void;
}

export const TodayView: React.FC<TodayViewProps> = ({
  tasks,
  subjects,
  sessions = [],
  settings,
  selectedDate,
  onSelectDate,
  onToggleTaskComplete,
  onAddTask,
  onUpdateTask,
  onDeleteTask,
  onStartFocusForTask,
  onNavigateToSubjects,
}) => {
  const todayStr = getTodayStr();
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newSubjectId, setNewSubjectId] = useState(subjects[0]?.id || '');
  const [newTargetPomodoros, setNewTargetPomodoros] = useState(1);
  const [newTaskDate, setNewTaskDate] = useState(selectedDate || todayStr);
  const [currentWeekOffset, setCurrentWeekOffset] = useState(0);

  // Edit task state
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [editSubjectId, setEditSubjectId] = useState('');
  const [editTargetPomodoros, setEditTargetPomodoros] = useState(1);
  const [editTaskDate, setEditTaskDate] = useState('');
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);

  // Sync newTaskDate when selectedDate changes
  useEffect(() => {
    setNewTaskDate(selectedDate);
  }, [selectedDate]);

  // Subject lookup helper (fallback to 未分類 if not found)
  const getSubject = (id: string) => {
    const found = subjects.find((s) => s.id === id);
    if (found) return found;
    if (id === UNCATEGORIZED_SUBJECT_ID) {
      return { id: UNCATEGORIZED_SUBJECT_ID, name: UNCATEGORIZED_SUBJECT_NAME, color: '#78716C', createdAt: '' };
    }
    return undefined;
  };

  // Dynamic base date for mini calendar based on real current date
  const now = new Date();
  const baseDate = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  baseDate.setDate(baseDate.getDate() + currentWeekOffset * 7);

  // Compute Sunday of that week
  const dayOfWeek = baseDate.getDay(); // 0 is Sunday
  const startOfWeek = new Date(baseDate);
  startOfWeek.setDate(baseDate.getDate() - dayOfWeek);

  const weekDays = Array.from({ length: 7 }).map((_, idx) => {
    const d = new Date(startOfWeek);
    d.setDate(startOfWeek.getDate() + idx);
    const dateStr = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(
      d.getDate()
    ).padStart(2, '0')}`;
    return {
      dateStr,
      dayNum: d.getDate(),
      month: d.getMonth() + 1,
      year: d.getFullYear(),
      dayName: ['日', '一', '二', '三', '四', '五', '六'][idx],
      isToday: dateStr === todayStr,
    };
  });

  // Strictly filter tasks for the currently selected date:
  // "出邊只會顯示當日要做嘅嘢"
  const filteredTasks = tasks.filter((t) => t.date === selectedDate);
  const completedCount = filteredTasks.filter((t) => t.completed).length;
  const totalCount = filteredTasks.length;

  const isShowingToday = selectedDate === todayStr;

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    let subId = newSubjectId;
    if (!subId) {
      if (subjects.length > 0) {
        subId = subjects[0].id;
      } else {
        subId = UNCATEGORIZED_SUBJECT_ID;
      }
    }

    const taskTargetDate = newTaskDate || selectedDate || todayStr;

    onAddTask({
      title: newTitle.trim(),
      subjectId: subId,
      date: taskTargetDate,
      targetPomodoros: Number(newTargetPomodoros) || 1,
    });

    setNewTitle('');
    setIsAddModalOpen(false);
  };

  return (
    <div className="pb-28 px-4 pt-3 max-w-md mx-auto">
      {/* Top Header Bar - Clean and minimalist */}
      <header className="flex items-center justify-between py-2">
        <h1 className="text-xl font-bold tracking-tight text-stone-900 dark:text-stone-100">
          專注蕃茄鐘
        </h1>
      </header>

      {/* Calendar Card */}
      <div className="mt-2 bg-white dark:bg-stone-800 rounded-2xl p-4 shadow-xs border border-stone-200/70 dark:border-stone-700/60">
        {/* Month Selector Bar & Jump to Today */}
        <div className="flex items-center justify-between mb-3 px-1">
          <div className="flex items-center gap-2">
            <span className="text-base font-bold text-stone-800 dark:text-stone-200">
              {weekDays[3]?.year}年 {weekDays[3]?.month}月
            </span>
            {!isShowingToday && (
              <button
                onClick={() => {
                  setCurrentWeekOffset(0);
                  onSelectDate(todayStr);
                }}
                className="px-2 py-0.5 text-[11px] font-semibold bg-orange-50 dark:bg-stone-700 text-[#E2583E] dark:text-orange-400 rounded-full hover:bg-orange-100 transition-colors cursor-pointer"
                type="button"
              >
                返回今日
              </button>
            )}
          </div>
          <div className="flex items-center gap-1">
            <button
              onClick={() => setCurrentWeekOffset((prev) => prev - 1)}
              className="w-7 h-7 flex items-center justify-center rounded-full text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-700 transition-colors cursor-pointer"
              aria-label="上一星期"
              type="button"
            >
              <ChevronLeft size={16} />
            </button>
            <button
              onClick={() => setCurrentWeekOffset((prev) => prev + 1)}
              className="w-7 h-7 flex items-center justify-center rounded-full text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-700 transition-colors cursor-pointer"
              aria-label="下一星期"
              type="button"
            >
              <ChevronRight size={16} />
            </button>
          </div>
        </div>

        {/* Days of week header */}
        <div className="grid grid-cols-7 text-center mb-2">
          {weekDays.map((d, i) => (
            <div
              key={i}
              className={`text-xs font-medium py-1 ${
                d.isToday
                  ? 'text-[#E2583E] font-bold'
                  : 'text-stone-400 dark:text-stone-500'
              }`}
            >
              {d.dayName}
            </div>
          ))}
        </div>

        {/* Date numbers row */}
        <div className="grid grid-cols-7 gap-1 text-center">
          {weekDays.map((d) => {
            const isSelected = d.dateStr === selectedDate;
            const hasTasks = tasks.some((t) => t.date === d.dateStr);

            return (
              <button
                key={d.dateStr}
                onClick={() => onSelectDate(d.dateStr)}
                type="button"
                className={`group relative flex flex-col items-center justify-center h-12 w-full rounded-xl transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-[#E2583E] text-white shadow-md shadow-orange-500/25 font-bold'
                    : d.isToday
                    ? 'bg-orange-50 dark:bg-orange-950/40 text-[#E2583E] dark:text-orange-400 font-bold border border-orange-200/60 dark:border-orange-800/60'
                    : 'text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-700/60 font-medium'
                }`}
              >
                <span className="text-sm">{d.dayNum}</span>

                {/* Task indicator dot */}
                {hasTasks && (
                  <span
                    className={`w-1.5 h-1.5 rounded-full mt-0.5 ${
                      isSelected
                        ? 'bg-white'
                        : 'bg-[#E2583E]'
                    }`}
                  />
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Date Context Header Bar */}
      <div className="flex items-center justify-between mt-5 mb-2 px-1">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-stone-900 dark:text-stone-100">
              {isShowingToday ? '今日溫習任務' : `${formatDateZh(selectedDate)}`}
            </h2>
            {isShowingToday ? (
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-orange-100 dark:bg-orange-950/50 text-[#E2583E] dark:text-orange-400 font-bold">
                當日待辦
              </span>
            ) : (
              <button
                onClick={() => {
                  setCurrentWeekOffset(0);
                  onSelectDate(todayStr);
                }}
                className="text-xs text-[#E2583E] hover:underline flex items-center gap-0.5 cursor-pointer font-medium"
                type="button"
              >
                <ArrowLeft size={12} />
                <span>返回今天</span>
              </button>
            )}
          </div>
          <p className="text-[11px] text-stone-400 mt-0.5">
            出邊僅顯示當日要做嘅事項 ({completedCount}/{totalCount} 完成)
          </p>
        </div>

        {/* Quick Add Button */}
        <button
          onClick={() => {
            setNewTaskDate(selectedDate);
            if (subjects.length > 0 && !newSubjectId) {
              setNewSubjectId(subjects[0].id);
            }
            setIsAddModalOpen(true);
          }}
          className="flex items-center gap-1 text-xs font-bold text-[#E2583E] dark:text-orange-400 hover:opacity-85 px-2 py-1 cursor-pointer"
          type="button"
        >
          <Plus size={16} />
          <span>安排任務</span>
        </button>
      </div>

      {/* Tasks List for the Selected Date */}
      <div className="space-y-2.5 mt-2">
        {filteredTasks.length === 0 ? (
          <div className="text-center py-10 px-4 bg-white dark:bg-stone-800 rounded-2xl border border-dashed border-stone-200 dark:border-stone-700/80">
            <CalendarDays className="w-10 h-10 text-stone-300 dark:text-stone-600 mx-auto mb-2" />
            <h3 className="text-sm font-bold text-stone-700 dark:text-stone-200">
              {isShowingToday ? '今天暫無安排溫習任務' : `「${selectedDate}」暫無溫習任務`}
            </h3>
            <p className="text-xs text-stone-400 mt-1 max-w-xs mx-auto">
              出邊頁面只會顯示當日排定要做嘅事項。點擊右下角「+」或在上方「安排任務」為這一天設定溫習主題！
            </p>
            <button
              onClick={() => {
                setNewTaskDate(selectedDate);
                setIsAddModalOpen(true);
              }}
              className="mt-4 px-4 py-2 bg-[#E2583E] text-white text-xs font-bold rounded-xl shadow-xs hover:bg-[#D1492F] transition-colors cursor-pointer inline-flex items-center gap-1.5"
              type="button"
            >
              <Plus size={14} />
              <span>新增當日任務</span>
            </button>
          </div>
        ) : (
          filteredTasks.map((task) => {
            const subject = getSubject(task.subjectId);

            // Compute real duration spent on this task (precise to the second)
            const taskSessions = sessions.filter(
              (s) => s.taskId === task.id || (s.topicName === task.title && s.date === task.date)
            );
            const focusSessions = taskSessions.filter((s) => s.type === 'focus');
            const recordedSeconds = taskSessions.reduce((acc, s) => acc + getSessionSeconds(s), 0);
            const actualSecondsSpent = task.actualSeconds !== undefined && task.actualSeconds > 0
              ? task.actualSeconds
              : (recordedSeconds > 0 ? recordedSeconds : (task.actualMinutes ? task.actualMinutes * 60 : 0));

            const totalRecordedSessions = focusSessions.length;
            const fullPomodoros = focusSessions.filter((s) => s.isFull).length;
            const partialPomodoros = Math.max(0, totalRecordedSessions - fullPomodoros);
            const effectiveFullCount = Math.max(task.completedPomodoros, fullPomodoros);
            const effectiveTotalCount = Math.max(effectiveFullCount + partialPomodoros, totalRecordedSessions);
            const totalSlots = Math.max(task.targetPomodoros, effectiveTotalCount, 1);

            return (
              <div
                key={task.id}
                className={`group flex items-center justify-between p-3.5 bg-white dark:bg-stone-800 rounded-2xl shadow-xs border transition-all duration-200 ${
                  task.completed
                    ? 'border-stone-200/50 dark:border-stone-800 bg-stone-50/50 dark:bg-stone-800/40 opacity-80'
                    : 'border-stone-200/80 dark:border-stone-700 hover:border-orange-200 dark:hover:border-stone-600'
                }`}
              >
                {/* Left checkmark + title + subject + actual minutes */}
                <div className="flex items-center gap-3 flex-1 min-w-0">
                  <button
                    onClick={() => onToggleTaskComplete(task.id)}
                    className={`w-6 h-6 rounded-full flex items-center justify-center transition-all cursor-pointer shrink-0 ${
                      task.completed
                        ? 'bg-emerald-500 text-white shadow-xs'
                        : 'border-2 border-stone-300 dark:border-stone-600 hover:border-[#E2583E]'
                    }`}
                    aria-label={task.completed ? '標記為未完成' : '標記為已完成'}
                    type="button"
                  >
                    {task.completed && <Check size={14} strokeWidth={3} />}
                  </button>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span
                        className={`text-sm font-semibold truncate ${
                          task.completed
                            ? 'line-through text-stone-400 dark:text-stone-500'
                            : 'text-stone-800 dark:text-stone-100'
                        }`}
                      >
                        {task.title}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 mt-1">
                      {subject && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-semibold bg-stone-100 dark:bg-stone-700/60 text-stone-600 dark:text-stone-300">
                          <span
                            className="w-1.5 h-1.5 rounded-full"
                            style={{ backgroundColor: subject.color }}
                          />
                          <span>{subject.name}</span>
                        </span>
                      )}

                      {/* Pomodoro count icons */}
                      <div className="flex items-center gap-0.5">
                        {Array.from({ length: totalSlots }).map((_, i) => {
                          const isFull = i < effectiveFullCount;
                          const isPartial = !isFull && i < effectiveTotalCount;
                          return (
                            <TomatoIcon
                              key={i}
                              size={13}
                              filled={isFull}
                              partial={isPartial}
                            />
                          );
                        })}
                      </div>

                      {/* Real time spent display down to minutes and seconds */}
                      {actualSecondsSpent > 0 ? (
                        <span className="text-[11px] font-bold text-orange-600 dark:text-orange-400 ml-0.5">
                          用咗 {formatDurationZh(actualSecondsSpent)}
                          <span className="text-stone-500 dark:text-stone-400 font-normal ml-1">
                            ({effectiveTotalCount}/{task.targetPomodoros} 次專注{effectiveFullCount > 0 ? ` · ${effectiveFullCount} 完整蕃茄` : ''})
                          </span>
                        </span>
                      ) : (
                        <span className="text-[11px] font-mono font-medium text-stone-500 dark:text-stone-400 ml-0.5">
                          {effectiveTotalCount}/{task.targetPomodoros} 次專注
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Quick Action Button: Play Pomodoro */}
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => onStartFocusForTask(task)}
                    className="w-8 h-8 rounded-full flex items-center justify-center bg-orange-50 dark:bg-stone-700 text-orange-600 dark:text-orange-400 hover:bg-orange-100 dark:hover:bg-stone-600 transition-colors cursor-pointer"
                    title="開始此任務專注"
                    aria-label="開始此任務專注"
                    type="button"
                  >
                    <Play size={14} className="ml-0.5 fill-current" />
                  </button>

                  <button
                    onClick={() => {
                      setEditingTask(task);
                      setEditTitle(task.title);
                      setEditSubjectId(task.subjectId);
                      setEditTargetPomodoros(task.targetPomodoros);
                      setEditTaskDate(task.date || selectedDate || todayStr);
                      setIsEditModalOpen(true);
                    }}
                    className="w-8 h-8 rounded-full flex items-center justify-center text-stone-500 hover:text-stone-800 dark:text-stone-400 dark:hover:text-stone-100 bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 transition-colors cursor-pointer shadow-2xs"
                    title="編輯任務"
                    aria-label="編輯任務"
                    type="button"
                  >
                    <Pencil size={13} />
                  </button>

                  <button
                    onClick={() => onDeleteTask(task.id)}
                    className="w-8 h-8 rounded-full flex items-center justify-center text-rose-500 hover:text-rose-700 dark:text-rose-400 dark:hover:text-rose-300 bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 transition-colors cursor-pointer shadow-2xs"
                    title="刪除任務"
                    aria-label="刪除任務"
                    type="button"
                  >
                    <Trash2 size={13} />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Floating Action Button (Add Task) */}
      <div className="fixed bottom-24 right-5 sm:right-auto sm:left-1/2 sm:translate-x-36 z-30">
        <button
          onClick={() => {
            setNewTaskDate(selectedDate);
            if (subjects.length > 0 && !newSubjectId) {
              setNewSubjectId(subjects[0].id);
            }
            setIsAddModalOpen(true);
          }}
          className="w-13 h-13 rounded-full bg-[#E2583E] hover:bg-[#D1492F] active:scale-95 text-white shadow-xl shadow-orange-500/35 flex items-center justify-center transition-all cursor-pointer"
          aria-label="新增溫習任務"
          type="button"
        >
          <Plus size={26} strokeWidth={2.5} />
        </button>
      </div>

      {/* Add Task Modal with explicit Year, Month, Day selector */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white dark:bg-stone-800 rounded-3xl p-6 w-full max-w-sm shadow-2xl border border-stone-200/80 dark:border-stone-700 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-stone-100 dark:border-stone-700">
              <h3 className="text-base font-bold text-stone-900 dark:text-stone-100">
                新增溫習任務
              </h3>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="w-7 h-7 flex items-center justify-center rounded-full text-stone-400 hover:text-stone-600 dark:hover:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-700 cursor-pointer"
                type="button"
              >
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleCreateTask} className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-stone-600 dark:text-stone-300 mb-1.5">
                  任務名稱 / Topic
                </label>
                <input
                  type="text"
                  required
                  placeholder="例：數學常規試題複習"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-stone-50 dark:bg-stone-900 border border-stone-200 dark:border-stone-700 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#E2583E] dark:text-white"
                  autoFocus
                />
              </div>

              {/* Specific Date Picker (Year, Month, Day) */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-semibold text-stone-600 dark:text-stone-300 flex items-center gap-1">
                    <CalendarIcon size={13} className="text-[#E2583E]" />
                    <span>安排溫習日期 (年/月/日)</span>
                  </label>
                  <span className="text-[10px] text-stone-400">
                    出邊僅於該日顯示
                  </span>
                </div>

                <input
                  type="date"
                  required
                  value={newTaskDate}
                  onChange={(e) => setNewTaskDate(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-900 border border-stone-200 dark:border-stone-700 rounded-xl text-xs font-semibold text-stone-800 dark:text-stone-200 focus:outline-none focus:ring-2 focus:ring-[#E2583E] cursor-pointer"
                />

                {/* Quick Shortcuts */}
                <div className="flex items-center gap-2 mt-2">
                  <button
                    type="button"
                    onClick={() => setNewTaskDate(todayStr)}
                    className={`flex-1 py-1 rounded-lg text-[11px] font-semibold border transition-all cursor-pointer ${
                      newTaskDate === todayStr
                        ? 'border-[#E2583E] bg-orange-50 dark:bg-orange-950/40 text-[#E2583E]'
                        : 'border-stone-200 dark:border-stone-700 text-stone-600 dark:text-stone-400 hover:bg-stone-100'
                    }`}
                  >
                    今天
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const t = new Date();
                      t.setDate(t.getDate() + 1);
                      const tY = t.getFullYear();
                      const tM = String(t.getMonth() + 1).padStart(2, '0');
                      const tD = String(t.getDate()).padStart(2, '0');
                      setNewTaskDate(`${tY}-${tM}-${tD}`);
                    }}
                    className="flex-1 py-1 rounded-lg text-[11px] font-semibold border border-stone-200 dark:border-stone-700 text-stone-600 dark:text-stone-400 hover:bg-stone-100 transition-all cursor-pointer"
                  >
                    明天
                  </button>
                </div>
                <p className="text-[11px] text-stone-400 mt-1">
                  安排日期：{formatDateZh(newTaskDate)}
                </p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-600 dark:text-stone-300 mb-1.5">
                  所屬科目
                </label>
                {subjects.length > 0 ? (
                  <div className="grid grid-cols-3 gap-2">
                    {subjects.map((sub) => {
                      const isSelected = (newSubjectId || subjects[0]?.id) === sub.id;
                      return (
                        <button
                          type="button"
                          key={sub.id}
                          onClick={() => setNewSubjectId(sub.id)}
                          className={`flex items-center gap-1.5 px-2.5 py-2 rounded-xl text-xs font-medium border transition-all truncate cursor-pointer ${
                            isSelected
                              ? 'border-[#E2583E] bg-orange-50/70 dark:bg-orange-950/40 text-[#E2583E] font-bold shadow-xs'
                              : 'border-stone-200 dark:border-stone-700 text-stone-700 dark:text-stone-300 hover:bg-stone-50 dark:hover:bg-stone-700'
                          }`}
                        >
                          <span
                            className="w-2 h-2 rounded-full shrink-0"
                            style={{ backgroundColor: sub.color }}
                          />
                          <span className="truncate">{sub.name}</span>
                        </button>
                      );
                    })}
                  </div>
                ) : (
                  <div>
                    <div className="p-3 bg-stone-50 dark:bg-stone-900 rounded-xl border border-stone-200 dark:border-stone-700 text-xs text-stone-600 dark:text-stone-300">
                      <div className="flex items-center gap-1.5 font-semibold text-stone-700 dark:text-stone-300">
                        <span className="w-2 h-2 rounded-full bg-[#78716C]" />
                        <span>將自動歸類至「未分類」科目</span>
                      </div>
                      <p className="text-[11px] text-stone-400 mt-1">
                        系統會自動將任務安排於「未分類」科目中。您可隨時在「科目」分頁建立並管理專屬科目。
                      </p>
                    </div>
                  </div>
                )}
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-600 dark:text-stone-300 mb-1.5">
                  預計蕃茄鐘數量 (每個 {settings.focusMinutes} 分鐘)
                </label>
                <div className="flex items-center gap-2">
                  {[1, 2, 3, 4, 5].map((num) => (
                    <button
                      type="button"
                      key={num}
                      onClick={() => setNewTargetPomodoros(num)}
                      className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all flex flex-col items-center gap-0.5 cursor-pointer ${
                        newTargetPomodoros === num
                          ? 'bg-[#E2583E] text-white shadow-xs'
                          : 'bg-stone-100 dark:bg-stone-700 text-stone-700 dark:text-stone-300 hover:bg-stone-200 dark:hover:bg-stone-600'
                      }`}
                    >
                      <TomatoIcon size={14} filled={newTargetPomodoros === num} />
                      <span>{num} 個</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="pt-2 flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="flex-1 py-2.5 text-xs font-semibold text-stone-600 dark:text-stone-300 bg-stone-100 dark:bg-stone-700 rounded-xl hover:bg-stone-200 dark:hover:bg-stone-600 transition-colors cursor-pointer"
                >
                  取消
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 text-xs font-bold text-white bg-[#E2583E] hover:bg-[#D1492F] rounded-xl shadow-md shadow-orange-500/25 transition-all cursor-pointer"
                >
                  儲存任務
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      {/* Edit Task Modal */}
      {isEditModalOpen && editingTask && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white dark:bg-stone-800 rounded-3xl p-6 w-full max-w-sm shadow-2xl border border-stone-200/80 dark:border-stone-700">
            <h3 className="text-base font-bold text-stone-900 dark:text-stone-100 mb-1">
              編輯溫習任務
            </h3>
            <p className="text-xs text-stone-500 dark:text-stone-400 mb-4">
              修改任務標題、預定日期或目標蕃茄鐘（與科目歷程同步更新）。
            </p>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (!editTitle.trim() || !onUpdateTask || !editingTask) return;
                onUpdateTask(editingTask.id, {
                  title: editTitle.trim(),
                  subjectId: editSubjectId,
                  targetPomodoros: editTargetPomodoros,
                  date: editTaskDate,
                });
                setIsEditModalOpen(false);
                setEditingTask(null);
              }}
              className="space-y-4"
            >
              <div>
                <label className="block text-xs font-semibold text-stone-600 dark:text-stone-300 mb-1.5">
                  任務標題 (Topic)
                </label>
                <input
                  type="text"
                  required
                  value={editTitle}
                  onChange={(e) => setEditTitle(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-stone-50 dark:bg-stone-900 border border-stone-200 dark:border-stone-700 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#E2583E] dark:text-white"
                  autoFocus
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-600 dark:text-stone-300 mb-1.5">
                  預定溫習日期
                </label>
                <input
                  type="date"
                  required
                  value={editTaskDate}
                  onChange={(e) => setEditTaskDate(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-900 border border-stone-200 dark:border-stone-700 rounded-xl text-xs font-semibold text-stone-800 dark:text-stone-200 focus:outline-none focus:ring-2 focus:ring-[#E2583E] cursor-pointer"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-600 dark:text-stone-300 mb-1.5">
                  所屬科目
                </label>
                {subjects.length > 0 ? (
                  <div className="grid grid-cols-3 gap-2">
                    {subjects.map((sub) => {
                      const isSelected = editSubjectId === sub.id;
                      return (
                        <button
                          type="button"
                          key={sub.id}
                          onClick={() => setEditSubjectId(sub.id)}
                          className={`flex items-center gap-1.5 px-2.5 py-2 rounded-xl text-xs font-medium border transition-all truncate cursor-pointer ${
                            isSelected
                              ? 'border-[#E2583E] bg-orange-50/70 dark:bg-orange-950/40 text-[#E2583E] font-bold shadow-xs'
                              : 'border-stone-200 dark:border-stone-700 text-stone-700 dark:text-stone-300 hover:bg-stone-50 dark:hover:bg-stone-700'
                          }`}
                        >
                          <span
                            className="w-2 h-2 rounded-full shrink-0"
                            style={{ backgroundColor: sub.color }}
                          />
                          <span className="truncate">{sub.name}</span>
                        </button>
                      );
                    })}
                  </div>
                ) : null}
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-600 dark:text-stone-300 mb-1.5">
                  目標蕃茄鐘數量
                </label>
                <div className="flex items-center gap-2">
                  {[1, 2, 3, 4, 5].map((num) => (
                    <button
                      type="button"
                      key={num}
                      onClick={() => setEditTargetPomodoros(num)}
                      className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all flex flex-col items-center gap-0.5 cursor-pointer ${
                        editTargetPomodoros === num
                          ? 'bg-[#E2583E] text-white shadow-xs'
                          : 'bg-stone-100 dark:bg-stone-700 text-stone-700 dark:text-stone-300 hover:bg-stone-200 dark:hover:bg-stone-600'
                      }`}
                    >
                      <TomatoIcon size={14} filled={editTargetPomodoros === num} />
                      <span>{num} 個</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="pt-2 flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setIsEditModalOpen(false);
                    setEditingTask(null);
                  }}
                  className="flex-1 py-2.5 text-xs font-semibold text-stone-600 dark:text-stone-300 bg-stone-100 dark:bg-stone-700 rounded-xl hover:bg-stone-200 dark:hover:bg-stone-600 transition-colors cursor-pointer"
                >
                  取消
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 text-xs font-bold text-white bg-[#E2583E] hover:bg-[#D1492F] rounded-xl shadow-md shadow-orange-500/25 transition-all cursor-pointer"
                >
                  儲存修改
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
