import React, { useState } from 'react';
import { Minus, Plus, Volume2, Moon, Download, Upload, Trash2, X, AlertTriangle } from 'lucide-react';
import { AppSettings } from '../types';
import { playCompletionChime } from '../utils/audio';

interface SettingsViewProps {
  settings: AppSettings;
  onUpdateSettings: (newSettings: Partial<AppSettings>) => void;
  onExportData: () => void;
  onImportData: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onResetData: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  settings,
  onUpdateSettings,
  onExportData,
  onImportData,
  onResetData,
}) => {
  const [showResetConfirmModal, setShowResetConfirmModal] = useState(false);

  const adjustFocus = (delta: number) => {
    const val = Math.max(1, settings.focusMinutes + delta);
    onUpdateSettings({ focusMinutes: val });
  };

  const adjustShortBreak = (delta: number) => {
    const val = Math.max(1, settings.shortBreakMinutes + delta);
    onUpdateSettings({ shortBreakMinutes: val });
  };

  const adjustLongBreak = (delta: number) => {
    const val = Math.max(1, settings.longBreakMinutes + delta);
    onUpdateSettings({ longBreakMinutes: val });
  };

  const toggleSound = () => {
    const next = !settings.soundAlert;
    onUpdateSettings({ soundAlert: next });
    if (next) playCompletionChime();
  };

  const toggleDarkMode = () => {
    onUpdateSettings({ darkMode: !settings.darkMode });
  };

  return (
    <div className="pb-28 px-4 pt-4 max-w-md mx-auto">
      {/* Reset Confirmation Modal (Zero window.confirm, 100% works in iframes) */}
      {showResetConfirmModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/70 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-white dark:bg-stone-800 rounded-3xl p-6 max-w-xs w-full text-center shadow-2xl border border-stone-200 dark:border-stone-700 animate-in zoom-in-95 duration-150">
            <div className="w-12 h-12 rounded-full bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 mx-auto flex items-center justify-center mb-3">
              <AlertTriangle size={24} />
            </div>
            <h3 className="text-base font-bold text-stone-900 dark:text-white">
              確定要清空所有資料？
            </h3>
            <p className="text-xs text-stone-500 dark:text-stone-400 mt-2 leading-relaxed">
              這將會清除所有科目、溫習任務與歷程紀錄，並將連續天數歸零。此操作無法復原。
            </p>
            <div className="flex gap-2.5 mt-5">
              <button
                type="button"
                onClick={() => setShowResetConfirmModal(false)}
                className="flex-1 py-2.5 text-xs font-semibold bg-stone-100 dark:bg-stone-700 text-stone-700 dark:text-stone-200 rounded-xl hover:bg-stone-200 dark:hover:bg-stone-600 transition-colors cursor-pointer"
              >
                取消
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowResetConfirmModal(false);
                  onResetData();
                }}
                className="flex-1 py-2.5 text-xs font-bold bg-rose-600 hover:bg-rose-700 text-white rounded-xl shadow-xs transition-colors cursor-pointer"
              >
                確認清空
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <header className="py-2 mb-2">
        <h1 className="text-xl font-bold tracking-tight text-stone-900 dark:text-stone-100">
          系統設定
        </h1>
        <p className="text-xs text-stone-500 dark:text-stone-400 mt-1">
          個性化你的專注時段與提醒方式
        </p>
      </header>

      {/* Section 1: 蕃茄鐘時長 (分鐘) */}
      <section className="mt-4">
        <h2 className="text-xs font-bold text-[#E2583E] dark:text-orange-400 px-1 mb-2 tracking-wide">
          蕃茄鐘時長 (分鐘)
        </h2>

        <div className="bg-white dark:bg-stone-800 rounded-2xl p-2 shadow-xs border border-stone-200/70 dark:border-stone-700/60 divide-y divide-stone-100 dark:divide-stone-700/60">
          {/* 專注時間 */}
          <div className="flex items-center justify-between p-3">
            <div>
              <div className="text-sm font-semibold text-stone-800 dark:text-stone-100">
                專注時間
              </div>
              <div className="text-[11px] text-stone-400">標準專注時段</div>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => adjustFocus(-5)}
                className="w-8 h-8 flex items-center justify-center rounded-xl bg-stone-100 dark:bg-stone-700 text-stone-600 dark:text-stone-300 hover:bg-stone-200 active:scale-95 transition-all cursor-pointer"
                aria-label="減少專注時間"
                type="button"
              >
                <Minus size={15} />
              </button>
              <div className="flex items-center gap-0.5 bg-stone-50 dark:bg-stone-900 border border-stone-200 dark:border-stone-700 rounded-xl px-2 py-1">
                <input
                  type="number"
                  min="1"
                  value={settings.focusMinutes}
                  onChange={(e) => {
                    const val = parseInt(e.target.value, 10);
                    if (!isNaN(val)) {
                      onUpdateSettings({ focusMinutes: Math.max(1, val) });
                    }
                  }}
                  className="w-12 text-center text-sm font-bold font-mono text-stone-900 dark:text-white bg-transparent focus:outline-none"
                />
                <span className="text-xs text-stone-400 font-medium">分</span>
              </div>
              <button
                onClick={() => adjustFocus(5)}
                className="w-8 h-8 flex items-center justify-center rounded-xl bg-stone-100 dark:bg-stone-700 text-stone-600 dark:text-stone-300 hover:bg-stone-200 active:scale-95 transition-all cursor-pointer"
                aria-label="增加專注時間"
                type="button"
              >
                <Plus size={15} />
              </button>
            </div>
          </div>

          {/* 短休息時間 */}
          <div className="flex items-center justify-between p-3">
            <div>
              <div className="text-sm font-semibold text-stone-800 dark:text-stone-100">
                短休息時間
              </div>
              <div className="text-[11px] text-stone-400">每個蕃茄鐘間的短暫小休</div>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => adjustShortBreak(-1)}
                className="w-8 h-8 flex items-center justify-center rounded-xl bg-stone-100 dark:bg-stone-700 text-stone-600 dark:text-stone-300 hover:bg-stone-200 active:scale-95 transition-all cursor-pointer"
                aria-label="減少短休時間"
                type="button"
              >
                <Minus size={15} />
              </button>
              <div className="flex items-center gap-0.5 bg-stone-50 dark:bg-stone-900 border border-stone-200 dark:border-stone-700 rounded-xl px-2 py-1">
                <input
                  type="number"
                  min="1"
                  value={settings.shortBreakMinutes}
                  onChange={(e) => {
                    const val = parseInt(e.target.value, 10);
                    if (!isNaN(val)) {
                      onUpdateSettings({ shortBreakMinutes: Math.max(1, val) });
                    }
                  }}
                  className="w-12 text-center text-sm font-bold font-mono text-stone-900 dark:text-white bg-transparent focus:outline-none"
                />
                <span className="text-xs text-stone-400 font-medium">分</span>
              </div>
              <button
                onClick={() => adjustShortBreak(1)}
                className="w-8 h-8 flex items-center justify-center rounded-xl bg-stone-100 dark:bg-stone-700 text-stone-600 dark:text-stone-300 hover:bg-stone-200 active:scale-95 transition-all cursor-pointer"
                aria-label="增加短休時間"
                type="button"
              >
                <Plus size={15} />
              </button>
            </div>
          </div>

          {/* 長休息時間 */}
          <div className="flex items-center justify-between p-3">
            <div>
              <div className="text-sm font-semibold text-stone-800 dark:text-stone-100">
                長休息時間
              </div>
              <div className="text-[11px] text-stone-400">完成四個蕃茄後的深度放鬆</div>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => adjustLongBreak(-5)}
                className="w-8 h-8 flex items-center justify-center rounded-xl bg-stone-100 dark:bg-stone-700 text-stone-600 dark:text-stone-300 hover:bg-stone-200 active:scale-95 transition-all cursor-pointer"
                aria-label="減少長休時間"
                type="button"
              >
                <Minus size={15} />
              </button>
              <div className="flex items-center gap-0.5 bg-stone-50 dark:bg-stone-900 border border-stone-200 dark:border-stone-700 rounded-xl px-2 py-1">
                <input
                  type="number"
                  min="1"
                  value={settings.longBreakMinutes}
                  onChange={(e) => {
                    const val = parseInt(e.target.value, 10);
                    if (!isNaN(val)) {
                      onUpdateSettings({ longBreakMinutes: Math.max(1, val) });
                    }
                  }}
                  className="w-12 text-center text-sm font-bold font-mono text-stone-900 dark:text-white bg-transparent focus:outline-none"
                />
                <span className="text-xs text-stone-400 font-medium">分</span>
              </div>
              <button
                onClick={() => adjustLongBreak(5)}
                className="w-8 h-8 flex items-center justify-center rounded-xl bg-stone-100 dark:bg-stone-700 text-stone-600 dark:text-stone-300 hover:bg-stone-200 active:scale-95 transition-all cursor-pointer"
                aria-label="增加長休時間"
                type="button"
              >
                <Plus size={15} />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Section 2: 提示與外觀 */}
      <section className="mt-6">
        <h2 className="text-xs font-bold text-[#E2583E] dark:text-orange-400 px-1 mb-2 tracking-wide">
          提示與外觀
        </h2>

        <div className="bg-white dark:bg-stone-800 rounded-2xl p-2 shadow-xs border border-stone-200/70 dark:border-stone-700/60 divide-y divide-stone-100 dark:divide-stone-700/60">
          {/* 完結鈴聲提示 */}
          <div className="flex items-center justify-between p-3">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-orange-50 dark:bg-stone-700 text-[#E2583E] dark:text-orange-400 flex items-center justify-center">
                <Volume2 size={17} />
              </div>
              <div>
                <div className="text-sm font-semibold text-stone-800 dark:text-stone-100">
                  完結鈴聲提示
                </div>
                <div className="text-[11px] text-stone-400">蕃茄鐘計時結束時播放柔和提示音</div>
              </div>
            </div>
            <button
              onClick={toggleSound}
              type="button"
              className={`w-12 h-6.5 flex items-center rounded-full p-1 transition-colors cursor-pointer ${
                settings.soundAlert ? 'bg-[#E2583E]' : 'bg-stone-200 dark:bg-stone-700'
              }`}
            >
              <div
                className={`bg-white w-4.5 h-4.5 rounded-full shadow-md transform transition-transform ${
                  settings.soundAlert ? 'translate-x-5.5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* 深色主題模式 */}
          <div className="flex items-center justify-between p-3">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-indigo-50 dark:bg-stone-700 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
                <Moon size={17} />
              </div>
              <div>
                <div className="text-sm font-semibold text-stone-800 dark:text-stone-100">
                  深色主題模式
                </div>
                <div className="text-[11px] text-stone-400">降低夜間專注時的眼睛負擔</div>
              </div>
            </div>
            <button
              onClick={toggleDarkMode}
              type="button"
              className={`w-12 h-6.5 flex items-center rounded-full p-1 transition-colors cursor-pointer ${
                settings.darkMode ? 'bg-[#E2583E]' : 'bg-stone-200 dark:bg-stone-700'
              }`}
            >
              <div
                className={`bg-white w-4.5 h-4.5 rounded-full shadow-md transform transition-transform ${
                  settings.darkMode ? 'translate-x-5.5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>
        </div>
      </section>

      {/* Section 3: 數據備份與管理 */}
      <section className="mt-6">
        <h2 className="text-xs font-bold text-stone-500 dark:text-stone-400 px-1 mb-2 tracking-wide">
          學習數據備份與管理
        </h2>

        <div className="bg-white dark:bg-stone-800 rounded-2xl p-3 shadow-xs border border-stone-200/70 dark:border-stone-700/60 flex items-center justify-between gap-2">
          <button
            onClick={onExportData}
            type="button"
            className="flex-1 py-2 px-2.5 bg-stone-50 dark:bg-stone-700/60 hover:bg-stone-100 dark:hover:bg-stone-700 text-stone-700 dark:text-stone-200 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors border border-stone-200 dark:border-stone-600 cursor-pointer"
          >
            <Download size={14} />
            <span>導出備份</span>
          </button>

          <label className="flex-1 py-2 px-2.5 bg-stone-50 dark:bg-stone-700/60 hover:bg-stone-100 dark:hover:bg-stone-700 text-stone-700 dark:text-stone-200 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors border border-stone-200 dark:border-stone-600 cursor-pointer">
            <Upload size={14} />
            <span>匯入資料</span>
            <input
              type="file"
              accept=".json"
              onChange={onImportData}
              className="hidden"
            />
          </label>

          <button
            onClick={() => setShowResetConfirmModal(true)}
            type="button"
            className="py-2 px-2.5 bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 dark:hover:bg-rose-900/60 text-rose-600 dark:text-rose-300 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors border border-rose-200 dark:border-rose-900 cursor-pointer"
            title="清空所有資料"
          >
            <Trash2 size={14} />
            <span>清空資料</span>
          </button>
        </div>
      </section>

      {/* Section 4: 免責聲明與私隱政策 (Disclaimer & Privacy Policy) */}
      <section className="mt-6 mb-8">
        <h2 className="text-xs font-bold text-stone-500 dark:text-stone-400 px-1 mb-2 tracking-wide">
          免責聲明與私隱政策 (Disclaimer & Privacy Policy)
        </h2>
        <div className="bg-white dark:bg-stone-800 rounded-2xl p-4 shadow-xs border border-stone-200/70 dark:border-stone-700/60 text-xs text-stone-600 dark:text-stone-300 space-y-3 leading-relaxed">
          <p className="font-semibold text-stone-800 dark:text-stone-100">
            最後更新日期：2026年9月
          </p>
          <p>
            歡迎使用本應用程式（以下簡稱「本 App」）。在使用本 App 前，請仔細閱讀以下條款：
          </p>
          <div>
            <h3 className="font-bold text-stone-800 dark:text-stone-100 mb-1">1. 資料收集與儲存 (Data Storage)</h3>
            <ul className="list-disc pl-4 space-y-1 text-stone-500 dark:text-stone-400">
              <li><strong className="text-stone-700 dark:text-stone-300">純本地運作：</strong>本 App 不會要求用戶建立帳號或登入，亦不會主動收集、追蹤、傳輸或向任何外部伺服器上載你的任何個人資料。</li>
              <li><strong className="text-stone-700 dark:text-stone-300">本地儲存機制：</strong>你於本 App 內輸入的所有數據（包括但不限於計時紀錄、待辦事項及溫習科目名稱）均僅儲存於你個人裝置的本地瀏覽器 / 應用程式緩存（Local Storage）中。</li>
            </ul>
          </div>
          <div>
            <h3 className="font-bold text-stone-800 dark:text-stone-100 mb-1">2. 用戶責任與安全建議 (User Responsibility)</h3>
            <ul className="list-disc pl-4 space-y-1 text-stone-500 dark:text-stone-400">
              <li><strong className="text-stone-700 dark:text-stone-300">請勿輸入敏感個人資料：</strong>由於本 App 的設計目的僅為時間管理與學習紀錄，請勿於任何輸入欄位（如科目或任務名稱）填寫身分證號碼、密碼、住址、銀行戶口等敏感個人資訊。</li>
              <li><strong className="text-stone-700 dark:text-stone-300">本地資料保存：</strong>由於資料僅存在於你的裝置中，若你清除瀏覽器快取、卸載本 App 或更換裝置，相關資料可能會永久遺失。請自行承擔資料遺失之風險。</li>
            </ul>
          </div>
          <div>
            <h3 className="font-bold text-stone-800 dark:text-stone-100 mb-1">3. 責任限制與免責聲明 (Limitation of Liability)</h3>
            <ul className="list-disc pl-4 space-y-1 text-stone-500 dark:text-stone-400">
              <li><strong className="text-stone-700 dark:text-stone-300">「現狀」提供：</strong>本 App 係以「按現狀」（As-Is）及「按可提供性」基礎提供，不附帶任何形式的明示或暗示保證。</li>
              <li><strong className="text-stone-700 dark:text-stone-300">系統漏洞與第三方風險：</strong>雖然我們致力保障 App 的程式安全，但對於因用戶裝置本身之漏洞、惡意軟體、第三方套件漏洞、網絡攻擊或不可抗力因素所導致的資料外洩、遺失或損壞，本 App 開發者在法律允許的最大範圍內，概不承擔任何直接、間接、附帶或衍生之法律責任或賠償責任。</li>
            </ul>
          </div>
          <div>
            <h3 className="font-bold text-stone-800 dark:text-stone-100 mb-1">4. 條款修改 (Amendments)</h3>
            <p className="text-stone-500 dark:text-stone-400">
              開發者保留隨時修改本免責聲明之權利，修改後的條款一經發布即時生效。繼續使用本 App 即代表你同意接受最新版本的條款約束。
            </p>
          </div>
          <div className="pt-2 border-t border-stone-100 dark:border-stone-700 text-[11px] text-amber-600 dark:text-amber-400 font-medium">
            💡 小貼士：數據僅存於本地裝置。為保障私隱，請勿輸入密碼或身份證等個人敏感資料。
          </div>
        </div>
      </section>
    </div>
  );
};
