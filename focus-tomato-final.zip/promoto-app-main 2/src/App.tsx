/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Subject, Task, PomodoroSession, AppSettings, TabType } from './types';
import {
  INITIAL_SUBJECTS,
  INITIAL_TASKS,
  INITIAL_SESSIONS,
  INITIAL_SETTINGS,
} from './utils/initialData';
import { getTodayStr } from './utils/dateUtils';
import { ensureUncategorizedSubject, UNCATEGORIZED_SUBJECT_ID } from './utils/subjectUtils';
import { playCompletionChime, playSoftTick } from './utils/audio';
import { fireConfetti } from './utils/confetti';
import { BottomNavBar } from './components/BottomNavBar';
import { TodayView } from './components/TodayView';
import { SubjectsView } from './components/SubjectsView';
import { SubjectDetailView } from './components/SubjectDetailView';
import { SettingsView } from './components/SettingsView';
import { FocusTimerModal } from './components/FocusTimerModal';
import { FloatingTomatoWidget } from './components/FloatingTomatoWidget';

export default function App() {
  // Clean initialization: if legacy mock data exists, discard it so user starts with fresh/clean state
  useEffect(() => {
    // Purge old mock storage keys if present
    localStorage.removeItem('focus_tomato_subjects');
    localStorage.removeItem('focus_tomato_tasks');
    localStorage.removeItem('focus_tomato_sessions');
  }, []);

  // Persistent storage using versioned keys
  const [subjects, setSubjects] = useState<Subject[]>(() => {
    try {
      const saved = localStorage.getItem('focus_tomato_v2_subjects');
      return saved ? JSON.parse(saved) : INITIAL_SUBJECTS;
    } catch {
      return INITIAL_SUBJECTS;
    }
  });

  const [tasks, setTasks] = useState<Task[]>(() => {
    try {
      const saved = localStorage.getItem('focus_tomato_v2_tasks');
      return saved ? JSON.parse(saved) : INITIAL_TASKS;
    } catch {
      return INITIAL_TASKS;
    }
  });

  const [sessions, setSessions] = useState<PomodoroSession[]>(() => {
    try {
      const saved = localStorage.getItem('focus_tomato_v2_sessions');
      return saved ? JSON.parse(saved) : INITIAL_SESSIONS;
    } catch {
      return INITIAL_SESSIONS;
    }
  });

  const [settings, setSettings] = useState<AppSettings>(() => {
    try {
      const saved = localStorage.getItem('focus_tomato_v2_settings');
      if (saved) {
        const parsed = JSON.parse(saved);
        return {
          focusMinutes: parsed.focusMinutes ?? 25,
          shortBreakMinutes: parsed.shortBreakMinutes ?? 5,
          longBreakMinutes: parsed.longBreakMinutes ?? 15,
          soundAlert: parsed.soundAlert ?? true,
          darkMode: parsed.darkMode ?? false,
          streakDays: parsed.streakDays ?? 0,
        };
      }
      return INITIAL_SETTINGS;
    } catch {
      return INITIAL_SETTINGS;
    }
  });

  // Navigation State
  const [activeTab, setActiveTab] = useState<TabType>('today');
  const [selectedSubjectForDetail, setSelectedSubjectForDetail] = useState<Subject | null>(null);
  const [selectedDate, setSelectedDate] = useState<string>(() => getTodayStr());

  // Pomodoro Timer State
  const [sessionType, setSessionType] = useState<'focus' | 'short_break' | 'long_break'>('focus');
  const [activeTaskId, setActiveTaskId] = useState<string | null>(null);
  const [activeSubjectId, setActiveSubjectId] = useState<string>('');
  const [activeTopicTitle, setActiveTopicTitle] = useState<string>('自主學習溫習');

  // Time in seconds
  const [timeLeft, setTimeLeft] = useState<number>(settings.focusMinutes * 60);
  const [totalDuration, setTotalDuration] = useState<number>(settings.focusMinutes * 60);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [isTimerModalOpen, setIsTimerModalOpen] = useState<boolean>(false);
  const [hasStartedTimerOnce, setHasStartedTimerOnce] = useState<boolean>(false);

  // Sync dark mode class with html and body elements
  useEffect(() => {
    if (settings.darkMode) {
      document.documentElement.classList.add('dark');
      document.body.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
      document.body.classList.remove('dark');
    }
  }, [settings.darkMode]);

  // Persist to localStorage
  useEffect(() => {
    localStorage.setItem('focus_tomato_v2_subjects', JSON.stringify(subjects));
  }, [subjects]);

  useEffect(() => {
    localStorage.setItem('focus_tomato_v2_tasks', JSON.stringify(tasks));
  }, [tasks]);

  useEffect(() => {
    localStorage.setItem('focus_tomato_v2_sessions', JSON.stringify(sessions));
  }, [sessions]);

  useEffect(() => {
    localStorage.setItem('focus_tomato_v2_settings', JSON.stringify(settings));
  }, [settings]);

  // Alarm ringing state for continuous looping alert sound until switched off
  const [isAlarmRinging, setIsAlarmRinging] = useState<boolean>(false);

  // Disclaimer & Privacy Policy Acceptance Gate (Persisted in localStorage)
  const [hasAcceptedDisclaimer, setHasAcceptedDisclaimer] = useState<boolean>(() => {
    try {
      return localStorage.getItem('focus_tomato_accepted_disclaimer') === 'true';
    } catch {
      return false;
    }
  });

  const handleAcceptDisclaimer = () => {
    try {
      localStorage.setItem('focus_tomato_accepted_disclaimer', 'true');
    } catch {}
    setHasAcceptedDisclaimer(true);
  };

  const handleStopAlarm = () => {
    setIsAlarmRinging(false);
  };

  // Continuous alarm sound loop effect
  useEffect(() => {
    let alarmInterval: NodeJS.Timeout | null = null;
    if (isAlarmRinging && settings.soundAlert) {
      playCompletionChime();
      alarmInterval = setInterval(() => {
        playCompletionChime();
      }, 2800);
    }
    return () => {
      if (alarmInterval) clearInterval(alarmInterval);
    };
  }, [isAlarmRinging, settings.soundAlert]);

  // Timer interval hook
  useEffect(() => {
    let timer: NodeJS.Timeout | null = null;
    if (isRunning && timeLeft > 0) {
      timer = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            handleTimerComplete(true);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [isRunning, timeLeft]);

  // Current active task & subject
  const currentTask = tasks.find((t) => t.id === activeTaskId);
  const currentSubject =
    subjects.find((s) => s.id === (currentTask?.subjectId || activeSubjectId)) || subjects[0];

  // Handle Pomodoro session completion (only called when timer naturally completes or student marks complete)
  const handleTimerComplete = (isNaturalExpiry: boolean = false) => {
    setIsRunning(false);

    // Calculate real elapsed time in seconds (accurate to the second):
    // Only when full time elapsed (timeLeft <= 1 or elapsed >= totalDuration - 2) is it a full pomodoro
    const isFullPomodoro = timeLeft <= 1 || (totalDuration > 0 && totalDuration - timeLeft >= totalDuration - 2);

    const elapsedSeconds = isFullPomodoro
      ? totalDuration
      : Math.max(1, totalDuration - timeLeft);
    const actualMins = Math.max(1, Math.round(elapsedSeconds / 60));

    if (settings.soundAlert) {
      playCompletionChime();
      if (isNaturalExpiry) {
        setIsAlarmRinging(true);
      }
    }

    // Only fire celebratory confetti when completing a full pomodoro!
    if (isFullPomodoro) {
      fireConfetti();
    }

    // If it was a focus session, record the session & increment task pomodoros only if full
    if (sessionType === 'focus') {
      const newSession: PomodoroSession = {
        id: `sess-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
        taskId: activeTaskId || undefined,
        subjectId: currentSubject?.id || UNCATEGORIZED_SUBJECT_ID,
        topicName: currentTask?.title || activeTopicTitle,
        durationMinutes: actualMins,
        durationSeconds: elapsedSeconds,
        isFull: isFullPomodoro,
        completedAt: new Date().toISOString(),
        date: currentTask?.date || selectedDate || getTodayStr(),
        type: 'focus',
      };
      setSessions((prev) => [newSession, ...prev]);

      if (activeTaskId) {
        setTasks((prev) =>
          prev.map((t) => {
            if (t.id === activeTaskId) {
              const updatedCount = isFullPomodoro
                ? t.completedPomodoros + 1
                : t.completedPomodoros;
              return {
                ...t,
                completedPomodoros: updatedCount,
                completed: true,
                actualMinutes: (t.actualMinutes || 0) + actualMins,
                actualSeconds: (t.actualSeconds || 0) + elapsedSeconds,
                completedAt: new Date().toISOString(),
              };
            }
            return t;
          })
        );
      }

      // Automatically update streak if 0
      if (settings.streakDays === 0) {
        setSettings((prev) => ({ ...prev, streakDays: 1 }));
      }

      // Switch to short break automatically
      setSessionType('short_break');
      const breakSecs = settings.shortBreakMinutes * 60;
      setTimeLeft(breakSecs);
      setTotalDuration(breakSecs);
    } else {
      // Completed break, switch back to focus
      setSessionType('focus');
      const focusSecs = settings.focusMinutes * 60;
      setTimeLeft(focusSecs);
      setTotalDuration(focusSecs);
    }
  };

  // Toggle timer play / pause
  const handleToggleTimer = () => {
    if (!isRunning) {
      playSoftTick();
      setHasStartedTimerOnce(true);
    }
    setIsRunning((prev) => !prev);
  };

  // Manual complete pomodoro button
  const handleManualCompletePomodoro = () => {
    handleTimerComplete();
  };

  // Reset timer to original duration
  const handleResetTimer = () => {
    setIsRunning(false);
    let dur = settings.focusMinutes * 60;
    if (sessionType === 'short_break') dur = settings.shortBreakMinutes * 60;
    if (sessionType === 'long_break') dur = settings.longBreakMinutes * 60;
    setTimeLeft(dur);
    setTotalDuration(dur);
  };

  /**
   * Discard / Delete the active Pomodoro clock when started:
   * Terminates the timer and resets it WITHOUT RECORDING ANY DATA into sessions, tasks, or streak!
   */
  const handleDiscardActivePomodoro = () => {
    setIsRunning(false);
    const defaultSecs = settings.focusMinutes * 60;
    setTimeLeft(defaultSecs);
    setTotalDuration(defaultSecs);
    setSessionType('focus');
    setHasStartedTimerOnce(false);
    setIsTimerModalOpen(false);
    // Explicitly NO recording in sessions, tasks, or streak.
  };

  // Switch session type
  const handleChangeSessionType = (type: 'focus' | 'short_break' | 'long_break') => {
    setIsRunning(false);
    setSessionType(type);
    let mins = settings.focusMinutes;
    if (type === 'short_break') mins = settings.shortBreakMinutes;
    if (type === 'long_break') mins = settings.longBreakMinutes;
    setTimeLeft(mins * 60);
    setTotalDuration(mins * 60);
  };

  // Start focus session for specific task
  const handleStartFocusForTask = (task: Task) => {
    setActiveTaskId(task.id);
    setActiveSubjectId(task.subjectId);
    setActiveTopicTitle(task.title);
    setSessionType('focus');
    const secs = settings.focusMinutes * 60;
    setTimeLeft(secs);
    setTotalDuration(secs);
    setIsRunning(true);
    setHasStartedTimerOnce(true);
    setIsTimerModalOpen(true);
  };

  // Start focus for a topic name and subject (e.g. from Subject Detail)
  const handleStartFocusForTopic = (topicName: string, subjectId: string) => {
    const existingTask = tasks.find(
      (t) => t.title === topicName && t.subjectId === subjectId && t.date === selectedDate
    );
    if (existingTask) {
      handleStartFocusForTask(existingTask);
      return;
    }
    setActiveTaskId(null);
    setActiveSubjectId(subjectId);
    setActiveTopicTitle(topicName);
    setSessionType('focus');
    const secs = settings.focusMinutes * 60;
    setTimeLeft(secs);
    setTotalDuration(secs);
    setIsRunning(true);
    setHasStartedTimerOnce(true);
    setIsTimerModalOpen(true);
  };

  // Task actions
  const handleToggleTaskComplete = (taskId: string) => {
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id === taskId) {
          const nextCompleted = !t.completed;
          if (nextCompleted && settings.soundAlert) {
            playCompletionChime();
            fireConfetti();
          }
          return {
            ...t,
            completed: nextCompleted,
            completedAt: nextCompleted ? new Date().toISOString() : undefined,
          };
        }
        return t;
      })
    );
  };

  const handleAddTask = (
    newTaskData: Omit<Task, 'id' | 'createdAt' | 'completed' | 'completedPomodoros'>
  ) => {
    let targetSubjectId = newTaskData.subjectId;
    const subjectExists = subjects.some((s) => s.id === targetSubjectId);

    // If subject is unclassified or not found, place into "未分類" (create it if needed)
    if (!targetSubjectId || !subjectExists) {
      const { subjects: updatedSubjects, uncategorizedId } = ensureUncategorizedSubject(subjects);
      setSubjects(updatedSubjects);
      targetSubjectId = uncategorizedId;
    }

    const newTask: Task = {
      ...newTaskData,
      subjectId: targetSubjectId,
      id: `task-${Date.now()}`,
      completed: false,
      completedPomodoros: 0,
      actualMinutes: 0,
      createdAt: new Date().toISOString(),
    };
    setTasks((prev) => [newTask, ...prev]);
  };

  const handleDeleteTask = (taskId: string) => {
    setTasks((prev) => prev.filter((t) => t.id !== taskId));
    if (activeTaskId === taskId) {
      setActiveTaskId(null);
    }
  };

  const handleUpdateTask = (taskId: string, updatedData: Partial<Task>) => {
    const targetTask = tasks.find((t) => t.id === taskId);
    setTasks((prev) =>
      prev.map((t) => (t.id === taskId ? { ...t, ...updatedData } : t))
    );
    if (targetTask) {
      setSessions((prev) =>
        prev.map((s) => {
          if (s.taskId === taskId || s.topicName === targetTask.title) {
            return {
              ...s,
              ...(updatedData.title ? { topicName: updatedData.title } : {}),
              ...(updatedData.subjectId ? { subjectId: updatedData.subjectId } : {}),
            };
          }
          return s;
        })
      );
    }
  };

  // Subject actions
  const handleAddSubject = (name: string, color: string) => {
    const newSub: Subject = {
      id: `sub-${Date.now()}`,
      name,
      color,
      createdAt: new Date().toISOString(),
    };
    setSubjects((prev) => [...prev, newSub]);
    return newSub.id;
  };

  const handleUpdateSubject = (id: string, name: string, color: string) => {
    setSubjects((prev) =>
      prev.map((s) => (s.id === id ? { ...s, name, color } : s))
    );
    if (selectedSubjectForDetail?.id === id) {
      setSelectedSubjectForDetail((prev) =>
        prev ? { ...prev, name, color } : null
      );
    }
  };

  // Delete subject (Requirement 1 & 3: 允許剷除科目，並自動將項目移至「未分類」)
  const handleDeleteSubject = (id: string) => {
    // Other remaining subjects
    const remainingSubjects = subjects.filter((s) => s.id !== id);

    // Check if there are tasks or sessions under this subject that need a home
    const hasOrphans =
      tasks.some((t) => t.subjectId === id) || sessions.some((s) => s.subjectId === id);

    let finalSubjects = remainingSubjects;
    let uncategorizedId = UNCATEGORIZED_SUBJECT_ID;

    if (hasOrphans || remainingSubjects.length === 0) {
      const ensured = ensureUncategorizedSubject(remainingSubjects);
      finalSubjects = ensured.subjects;
      uncategorizedId = ensured.uncategorizedId;
    }

    setSubjects(finalSubjects);

    // Migrate all tasks belonging to the deleted subject to "未分類"
    setTasks((prev) =>
      prev.map((t) => (t.subjectId === id ? { ...t, subjectId: uncategorizedId } : t))
    );

    // Migrate all sessions belonging to the deleted subject to "未分類"
    setSessions((prev) =>
      prev.map((s) => (s.subjectId === id ? { ...s, subjectId: uncategorizedId } : s))
    );

    if (selectedSubjectForDetail?.id === id) {
      setSelectedSubjectForDetail(null);
    }
  };

  // Settings update
  const handleUpdateSettings = (newSet: Partial<AppSettings>) => {
    setSettings((prev) => {
      const next = { ...prev, ...newSet };
      if (!isRunning) {
        if (newSet.focusMinutes && sessionType === 'focus') {
          setTimeLeft(newSet.focusMinutes * 60);
          setTotalDuration(newSet.focusMinutes * 60);
        }
        if (newSet.shortBreakMinutes && sessionType === 'short_break') {
          setTimeLeft(newSet.shortBreakMinutes * 60);
          setTotalDuration(newSet.shortBreakMinutes * 60);
        }
        if (newSet.longBreakMinutes && sessionType === 'long_break') {
          setTimeLeft(newSet.longBreakMinutes * 60);
          setTotalDuration(newSet.longBreakMinutes * 60);
        }
      }
      return next;
    });
  };

  // Backup / Restore JSON
  const handleExportData = () => {
    const backup = {
      subjects,
      tasks,
      sessions,
      settings,
      version: '1.4.0',
      exportedAt: new Date().toISOString(),
    };
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(backup, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `focus_tomato_study_tool_backup_${selectedDate}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleImportData = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (parsed.subjects || parsed.tasks) {
          // Smart merge: combine existing local data with backup data without losing new local items (avoiding duplicate IDs)
          const existingSubjectIds = new Set(subjects.map((s) => s.id));
          const newSubjects = (parsed.subjects || []).filter((s: Subject) => !existingSubjectIds.has(s.id));
          const mergedSubjects = [...subjects, ...newSubjects];

          const existingTaskIds = new Set(tasks.map((t) => t.id));
          const newTasks = (parsed.tasks || []).filter((t: Task) => !existingTaskIds.has(t.id));
          const mergedTasks = [...tasks, ...newTasks];

          const existingSessionIds = new Set(sessions.map((s) => s.id));
          const newSessions = (parsed.sessions || []).filter((s: PomodoroSession) => !existingSessionIds.has(s.id));
          const mergedSessions = [...sessions, ...newSessions];

          setSubjects(mergedSubjects);
          setTasks(mergedTasks);
          if (parsed.sessions) {
            setSessions(mergedSessions);
          }
          
          alert(`資料匯入與合併成功！現有項目已全數保留，總計 ${mergedSubjects.length} 個科目、${mergedTasks.length} 個任務。`);
        } else {
          alert('匯入格式不正確。');
        }
      } catch {
        alert('匯入失敗，請確認檔案格式。');
      }
    };
    reader.readAsText(file);
  };

  // Clear all data
  const handleClearAllData = () => {
    setSubjects([]);
    setTasks([]);
    setSessions([]);
    setSettings(INITIAL_SETTINGS);
    localStorage.clear();
    setSelectedSubjectForDetail(null);
    handleDiscardActivePomodoro();
  };

  // Format time for ticker
  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  const timeDisplay = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
  const progressPercent = totalDuration > 0 ? (timeLeft / totalDuration) * 100 : 0;

  return (
    <div className="min-h-screen bg-[#F4F1EA] dark:bg-stone-950 text-stone-900 dark:text-stone-100 flex flex-col justify-between antialiased font-sans selection:bg-[#E2583E] selection:text-white transition-colors duration-200">
      
      {/* Alarm Ringing Banner (Stays until user actively switches off) */}
      {isAlarmRinging && (
        <div className="fixed top-0 left-0 right-0 z-50 bg-rose-600 text-white px-4 py-3 shadow-2xl flex items-center justify-between animate-bounce">
          <div className="flex items-center gap-2 max-w-[70%]">
            <span className="text-xl shrink-0">🔔</span>
            <div className="truncate">
              <p className="font-bold text-xs sm:text-sm truncate">蕃茄鐘時間到！提示音持續響起中</p>
              <p className="text-[11px] text-rose-100 truncate">請點擊右側按鈕關閉提示音。</p>
            </div>
          </div>
          <button
            onClick={handleStopAlarm}
            className="px-3.5 py-2 bg-white text-rose-600 hover:bg-rose-50 font-bold rounded-xl text-xs active:scale-95 transition-all shadow-md shrink-0 cursor-pointer"
            type="button"
          >
            關閉提示音 (Stop)
          </button>
        </div>
      )}

      {/* Mandatory Disclaimer & Privacy Policy Consent Modal */}
      {!hasAcceptedDisclaimer && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-stone-950/80 backdrop-blur-md animate-in fade-in duration-200">
          <div className="bg-white dark:bg-stone-900 rounded-3xl p-6 max-w-md w-full shadow-2xl border border-stone-200 dark:border-stone-800 flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-200">
            <div className="text-center mb-3">
              <span className="text-3xl">🍅</span>
              <h2 className="text-lg font-bold text-stone-900 dark:text-white mt-1">
                免責聲明與私隱政策
              </h2>
              <p className="text-xs text-stone-500 dark:text-stone-400 mt-0.5">
                最後更新日期：2026年9月
              </p>
            </div>

            <div className="flex-1 overflow-y-auto text-xs text-stone-600 dark:text-stone-300 space-y-3 pr-1 my-2 leading-relaxed border-y border-stone-100 dark:border-stone-800 py-3">
              <p>
                歡迎使用本應用程式（以下簡稱「本 App」）。在使用本 App 前，請仔細閱讀以下條款：
              </p>
              <div>
                <h3 className="font-bold text-stone-800 dark:text-stone-100 mb-1">1. 資料收集與儲存 (Data Storage)</h3>
                <ul className="list-disc pl-4 space-y-1 text-stone-500 dark:text-stone-400">
                  <li><strong className="text-stone-700 dark:text-stone-300">純本地運作：</strong>本 App 不會要求用戶建立帳號或登入，亦不會主動收集、追蹤、傳輸或向任何外部伺服器上載你的任何個人資料。</li>
                  <li><strong className="text-stone-700 dark:text-stone-300">本地儲存機制：</strong>你於本 App 內輸入的所有數據（包括但不限於計時紀錄、待辦事項及溫習科目名稱）均僅儲存於你個人裝置的本地瀏覽器 / 應用程式緩存（Local Storage）中。</li>
                </ul>
              </div>
              <div>
                <h3 className="font-bold text-stone-800 dark:text-stone-100 mb-1">2. 用戶責任與安全建議 (User Responsibility)</h3>
                <ul className="list-disc pl-4 space-y-1 text-stone-500 dark:text-stone-400">
                  <li><strong className="text-stone-700 dark:text-stone-300">請勿輸入敏感個人資料：</strong>由於本 App 的設計目的僅為時間管理與學習紀錄，請勿於任何輸入欄位（如科目或任務名稱）填寫身分證號碼、密碼、住址、銀行戶口等敏感個人資訊。</li>
                  <li><strong className="text-stone-700 dark:text-stone-300">本地資料保存：</strong>由於資料僅存在於你的裝置中，若你清除瀏覽器快取、卸載本 App 或更換裝置，相關資料可能會永久遺失。請自行承擔資料遺失之風險。</li>
                </ul>
              </div>
              <div>
                <h3 className="font-bold text-stone-800 dark:text-stone-100 mb-1">3. 責任限制與免責聲明 (Limitation of Liability)</h3>
                <ul className="list-disc pl-4 space-y-1 text-stone-500 dark:text-stone-400">
                  <li><strong className="text-stone-700 dark:text-stone-300">「現狀」提供：</strong>本 App 係以「按現狀」（As-Is）及「按可提供性」基礎提供，不附帶任何形式的明示或暗示保證。</li>
                  <li><strong className="text-stone-700 dark:text-stone-300">系統漏洞與第三方風險：</strong>雖然我們致力保障 App 的程式安全，但對於因用戶裝置本身之漏洞、惡意軟體、第三方套件漏洞、網絡攻擊或不可抗力因素所導致的資料外洩、遺失或損壞，本 App 開發者在法律允許的最大範圍內，概不承擔任何直接、間接、附帶或衍生之法律責任或賠償責任。</li>
                </ul>
              </div>
              <div>
                <h3 className="font-bold text-stone-800 dark:text-stone-100 mb-1">4. 條款修改 (Amendments)</h3>
                <p className="text-stone-500 dark:text-stone-400">
                  開發者保留隨時修改本免責聲明之權利，修改後的條款一經發布即時生效。繼續使用本 App 即代表你同意接受最新版本的條款約束。
                </p>
              </div>
              <div className="p-2.5 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-xl text-[11px] text-amber-700 dark:text-amber-300 font-medium">
                💡 小貼士：數據僅存於本地裝置。為保障私隱，請勿輸入密碼或身份證等個人敏感資料。
              </div>
            </div>

            <div className="mt-3">
              <button
                type="button"
                onClick={handleAcceptDisclaimer}
                className="w-full py-3 bg-gradient-to-r from-orange-500 to-[#E2583E] hover:from-orange-600 hover:to-[#D1492F] text-white font-bold rounded-2xl shadow-md transition-all active:scale-95 text-sm cursor-pointer"
              >
                我已閱讀並同意上述條款 (Agree & Continue)
              </button>
              <p className="text-[10px] text-center text-stone-400 mt-2">
                必須同意免責聲明與私隱政策方可使用本應用程式。
              </p>
            </div>
          </div>
        </div>
      )}

      {/* App Shell Container */}
      <div className="w-full max-w-md mx-auto min-h-screen flex flex-col bg-[#F9F7F4] dark:bg-stone-900 sm:shadow-2xl sm:border-x sm:border-stone-200/80 dark:sm:border-stone-800 transition-colors duration-200 relative overflow-hidden">
        
        {/* Main Content Area (Clean top without fake status bar) */}
        <main className="flex-1 flex flex-col overflow-y-auto pt-2">
          {activeTab === 'today' && (
            <TodayView
              tasks={tasks}
              subjects={subjects}
              sessions={sessions}
              settings={settings}
              selectedDate={selectedDate}
              onSelectDate={setSelectedDate}
              onToggleTaskComplete={handleToggleTaskComplete}
              onAddTask={handleAddTask}
              onUpdateTask={handleUpdateTask}
              onDeleteTask={handleDeleteTask}
              onStartFocusForTask={handleStartFocusForTask}
              onNavigateToSubjects={() => setActiveTab('subjects')}
            />
          )}

          {activeTab === 'subjects' && (
            selectedSubjectForDetail ? (
              <SubjectDetailView
                subject={selectedSubjectForDetail}
                tasks={tasks}
                sessions={sessions}
                settings={settings}
                onBack={() => setSelectedSubjectForDetail(null)}
                onStartFocus={handleStartFocusForTopic}
                onDeleteSubject={handleDeleteSubject}
                onUpdateTask={handleUpdateTask}
                onDeleteTask={handleDeleteTask}
                onAddTopicForSubject={(title, targetPomodoros, date) => {
                  handleAddTask({
                    title,
                    subjectId: selectedSubjectForDetail.id,
                    date: date || selectedDate || getTodayStr(),
                    targetPomodoros,
                  });
                }}
              />
            ) : (
              <SubjectsView
                subjects={subjects}
                tasks={tasks}
                sessions={sessions}
                onSelectSubject={(sub) => setSelectedSubjectForDetail(sub)}
                onAddSubject={handleAddSubject}
                onUpdateSubject={handleUpdateSubject}
                onDeleteSubject={handleDeleteSubject}
              />
            )
          )}

          {activeTab === 'settings' && (
            <SettingsView
              settings={settings}
              onUpdateSettings={handleUpdateSettings}
              onExportData={handleExportData}
              onImportData={handleImportData}
              onResetData={handleClearAllData}
            />
          )}
        </main>

        {/* Floating Tomato Widget (Displays when timer is ticking or active and user is outside modal) */}
        {!isTimerModalOpen && (isRunning || hasStartedTimerOnce) && (
          <FloatingTomatoWidget
            timeDisplay={timeDisplay}
            isRunning={isRunning}
            progressPercent={progressPercent}
            sessionType={sessionType}
            taskTitle={currentTask?.title || activeTopicTitle}
            subjectName={currentSubject?.name}
            subjectColor={currentSubject?.color}
            onExpand={() => setIsTimerModalOpen(true)}
            onTogglePlay={handleToggleTimer}
            onDiscard={handleDiscardActivePomodoro}
          />
        )}

        {/* Fixed Bottom Navigation Bar */}
        <BottomNavBar
          activeTab={activeTab}
          onTabChange={(tab) => {
            setActiveTab(tab);
            if (tab !== 'subjects') {
              setSelectedSubjectForDetail(null);
            }
          }}
        />

        {/* Focus Timer Modal (Tomato Illustration with Time Display on it!) */}
        <FocusTimerModal
          isOpen={isTimerModalOpen}
          onClose={() => setIsTimerModalOpen(false)}
          onMinimize={() => setIsTimerModalOpen(false)}
          task={currentTask}
          subject={currentSubject}
          allTasks={tasks}
          sessions={sessions}
          onSelectTask={(task) => {
            setActiveTaskId(task.id);
            setActiveSubjectId(task.subjectId);
            setActiveTopicTitle(task.title);
          }}
          timeLeft={timeLeft}
          totalDuration={totalDuration}
          isRunning={isRunning}
          sessionType={sessionType}
          settings={settings}
          onToggleTimer={handleToggleTimer}
          onResetTimer={handleResetTimer}
          onDiscardTimer={handleDiscardActivePomodoro}
          onCompletePomodoro={handleManualCompletePomodoro}
          onChangeSessionType={handleChangeSessionType}
          isAlarmRinging={isAlarmRinging}
          onStopAlarm={handleStopAlarm}
        />
      </div>
    </div>
  );
}
