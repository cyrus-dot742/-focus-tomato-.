import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = process.env.PORT || 3000;
  const isProduction = process.env.NODE_ENV === 'production';

  // 1. Enforce Trust Proxy if behind a reverse proxy (Cloud Run / load balancer)
  app.set('trust proxy', 1);

  // 2. Security Headers via Helmet (CSP, HSTS, X-Frame-Options, X-Content-Type-Options)
  app.use(
    helmet({
      contentSecurityPolicy: isProduction ? {
        directives: {
          defaultSrc: ["'self'"],
          scriptSrc: ["'self'"], // No inline/eval scripts — Vite emits external module scripts only
          styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
          fontSrc: ["'self'", "https://fonts.gstatic.com", "data:"],
          imgSrc: ["'self'", "data:", "blob:"],
          connectSrc: ["'self'"], // No external API calls are made from the client
          objectSrc: ["'none'"],
          baseUri: ["'self'"],
          formAction: ["'self'"],
          frameAncestors: ["'none'"],
          upgradeInsecureRequests: [],
        },
      } : false, // Disable strict CSP in dev mode to allow Vite HMR and inline scripts/client
      crossOriginEmbedderPolicy: false,
      hsts: {
        maxAge: 63072000, // 2 years HSTS
        includeSubDomains: true,
        preload: true,
      },
    })
  );

  // 3. CORS Protection (restrictive, fail-closed policy)
  // In production, every cross-origin request is DENIED unless its Origin is
  // explicitly allow-listed via APP_URL. If APP_URL is unset, CORS fails closed
  // (no origin is allowed) instead of silently allowing everything.
  const allowedOrigins = process.env.APP_URL
    ? process.env.APP_URL.split(',').map((o) => o.trim()).filter(Boolean)
    : [];
  app.use(
    cors({
      origin: (origin, callback) => {
        // Same-origin requests, curl, and non-browser clients send no Origin header.
        if (!origin) {
          callback(null, true);
          return;
        }
        // Fail closed: refuse any cross-origin origin not on the allow-list.
        if (isProduction && !allowedOrigins.includes(origin)) {
          callback(new Error('Not allowed by CORS'));
          return;
        }
        // Development only: allow all origins (Vite HMR / local tooling).
        callback(null, true);
      },
      credentials: true,
    })
  );

  // 4. Rate Limiting to prevent brute force / DDoS / abuse
  const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 300, // limit each IP to 300 requests per windowMs
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: 'Too many requests from this IP, please try again after 15 minutes.' },
  });
  app.use('/api/', limiter);

  // Body parsing with size limits to prevent payload attacks
  app.use(express.json({ limit: '1mb' }));
  app.use(express.urlencoded({ extended: true, limit: '1mb' }));

  // API health check and sample secure endpoint
  app.get('/api/health', (req, res) => {
    res.json({ status: 'healthy', timestamp: new Date().toISOString() });
  });

  // Vite integration for development vs static serving for production
  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
    app.use('*', async (req, res, next) => {
      try {
        const url = req.originalUrl;
        let template = fs.readFileSync(path.resolve(__dirname, 'index.html'), 'utf-8');
        template = await vite.transformIndexHtml(url, template);
        res.status(200).set({ 'Content-Type': 'text/html' }).end(template);
      } catch (e) {
        vite.ssrFixStacktrace(e as Error);
        next(e);
      }
    });
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    if (fs.existsSync(distPath)) {
      app.use(express.static(distPath));
      app.get('*', (req, res) => {
        res.sendFile(path.join(distPath, 'index.html'));
      });
    } else {
      app.get('*', (req, res) => {
        res.status(404).send('Application not built. Run npm run build.');
      });
    }
  }

  app.listen(Number(PORT), '0.0.0.0', () => {
    console.log(`> Secure server running on http://0.0.0.0:${PORT} [Production: ${isProduction}]`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
